# KidGuard (Android)

## Build
1. Install Android Studio. File > Open > this folder. Let Gradle sync.
2. (Nudity filter) put a TFLite model at app/src/main/assets/nsfw.tflite
   - input float32 [1,224,224,3] scaled 0..1, output [1,2] = [safe, nsfw]
   - Without it, everything else works and the filter is just off.
3. Plug in the kid's phone (USB debugging on) and press Run.

## What's new
- New KidGuard icon and teal, kid-friendly look. The kid screen says "Hi <name>!".
- Every text alert starts with the child's name: "KidGuard - Mia's phone: ...".
- Parent mode opens with a setup checklist that ticks off as you go.
- "Copy settings to another phone": save your limits/websites/number to a file in parent
  mode, then on the next phone tap "Copy settings from another phone" on the first screen
  (or "Load settings from a file" in parent mode). PIN and child's name are per-phone.
- Android 13+: if the Accessibility or SMS switch is greyed out, the checklist shows an
  "Allow restricted settings" step (App info > ⋮ > Allow restricted settings).

## First-time setup on the kid's phone
1. Open KidGuard, set the parent PIN.
2. Tap "Enable uninstall protection" > Activate.
3. Tap "Open Accessibility settings" > KidGuard > turn on.
4. Add allowed sites (one per line), set the time limit.
5. Type YOUR mobile number, tap "Allow texting" > Allow, then "Save settings".
   Tap "Send test alert": you should get a text, and it appears under Recent alerts.
6. Press Home. The phone is now in kid mode; "Parent login" changes things.
7. (Recommended) Device Owner lock, to block safe mode + factory reset + force-stop:
   - Remove all accounts from the phone first (Settings > Accounts, incl. Google).
   - With USB debugging on, run on your computer:
       adb shell dpm set-device-owner com.example.kidguard/.AdminReceiver
   - Re-add the accounts afterwards. Reopen KidGuard in parent mode: it should
     show "Safe-mode / factory-reset lock ON".
   - Some brands (Xiaomi, Huawei, some Samsung) refuse this command.
   - To undo: parent mode > "Remove ALL protection".

## Uninstalling
Parent mode > More > "Uninstall KidGuard" drops Device Owner and device admin, then opens Android's uninstall screen.

## What survives a reboot
- Accessibility service + device admin stay enabled across normal reboots.
- BootReceiver re-applies the Device Owner locks and texts you "Phone restarted"
  and whether protection is still ON.
- Without step 7, a kid can still boot into Safe Mode (third-party apps are
  disabled there) or factory reset. Step 7 blocks both.

## Alerts
Everything is saved in the app (parent mode > Recent alerts). Only two things are TEXTED to you:
1. The kid's "Ask for more time" request (one text per request, no repeats until it is answered or 30 min pass).
2. The nudity filter.
Blocked apps/sites, new apps, restarts, tamper attempts and "service stopped" are in-app log only
(to text one of them again, pass sms = true to Alerts.send / alertOnce for that event).
Your carrier's normal SMS charges apply.

## Giving extra time
- On the kid's phone: Ask for more time > a parent enters their PIN and taps +15 / +30 / +60. Works with no texting.
- In parent mode: "Give extra time today" buttons.
- By text: reply "OK 30" / "yes 30" / just "30" from your saved number. If your phone replies with RCS / chat
  features instead of a normal SMS, Android never delivers it to KidGuard: use the PIN buttons instead.
- Phone and messaging apps are never time-limited or blocked by default (change per app in Choose apps).

## Backup layer: a separate app lock (optional but recommended)
If you skip the Device Owner step, add a separate app-lock app as a second layer.
Use it to PIN-lock Settings, the Play Store and KidGuard itself.
It is not part of KidGuard and will not stop Safe Mode or a factory reset on its own,
so it works best alongside KidGuard (ideally plus Device Owner).
This tip is also shown inside the app under "Help & tips".

## No Android Studio? Let GitHub build it
1. Create a free GitHub account and a new repository.
2. Upload the CONTENTS of this folder (not the zip) to the repo root, so
   settings.gradle.kts sits at the top. Include the .github folder.
3. Open the Actions tab > "Build KidGuard APK" > wait for the green tick.
4. Download the KidGuard-apk artifact, unzip it, and install app-debug.apk on the phone.
Optional: Settings > Pages > deploy from the main branch to show index.html as a simple site.
