# KidGuard (Android)

## Build
1. Install Android Studio. File > Open > this folder. Let Gradle sync.
2. (Nudity filter, optional) put a TFLite model at app/src/main/assets/nsfw.tflite
   - Recommended: the Yahoo open_nsfw model, as converted at github.com/devzwy/open_nsfw_android
     (file: app/src/main/assets/nsfw.tflite on that repo's "dev" branch). NsfwScanner.kt is set up for it
     (YAHOO_STYLE = true). Output is [safe, nsfw].
   - For a model that wants plain RGB 0..1 instead, set YAHOO_STYLE = false in NsfwScanner.kt.
   - Without any model, everything else works and the filter is just off.
3. Plug in the kid's phone (USB debugging on) and press Run.

## What's new
- v1.8: After a "KG OFF" text, parent mode shows a red "Protection is OFF" card at the top with a
  "Turn protection back ON" button (same as texting KG ON). All your settings are kept.
- v1.7: TEXT KILL SWITCH. From your saved parent number, text (normal SMS, not RCS):
    KG PAUSE 1234  -> all blocking off for 2 hours, then back on by itself
    KG OFF 1234    -> fully off: blocking stops, Device Owner / safe-mode / factory-reset locks are released
    KG ON 1234     -> back on (Device Owner needs the adb step again if KG OFF released it)
  1234 is your parent PIN. KidGuard texts you back. Wrong PIN 5 times = commands ignored for 30 min.
  While KG OFF is active, opening KidGuard goes straight to parent mode (no PIN) until you text KG ON.
- v1.6: Your home-screen app (e.g. Nova Launcher) is never treated as a "new app", so choosing a new launcher
  can no longer lock you out. Its own settings screens (Nova Settings, etc.) are locked for the kid while its
  home screen still works. Parent mode (PIN) opens them for 10 minutes. Blocked attempts are logged in
  Recent alerts as "Blocked home-screen settings: <screen name>".
- Game ads are covered by a bouncing KidGuard logo (the ad still plays underneath so rewards arrive). Switch in parent mode > Game ads.
- New KidGuard icon and teal, kid-friendly look. The kid screen says "Hi <name>!".
- Every text alert starts with the child's name: "KidGuard - Mia's phone: ...".
- Parent mode opens with a setup checklist that ticks off as you go.
- "Copy settings to another phone": save your limits/websites/number to a file in parent
  mode, then on the next phone tap "Copy settings from another phone" on the first screen
  (or "Load settings from a file" in parent mode). PIN and child's name are per-phone.
- Android 13+: if the Accessibility or SMS switch is greyed out, the checklist shows an
  "Allow restricted settings" step (App info > ⋮ > Allow restricted settings).

## First-time setup on the kid's phone
1. Open KidGuard, set the parent PIN.
2. Tap "Enable uninstall protection" > Activate.
3. Tap "Open Accessibility settings" > KidGuard > turn on.
4. Add allowed sites (one per line), set the time limit.
5. Type YOUR mobile number, tap "Allow texting" > Allow, then "Save settings".
   Tap "Send test alert": you should get a text, and it appears under Recent alerts.
6. Press Home. The phone is now in kid mode; "Parent login" changes things.
7. (Recommended) Device Owner lock, to block safe mode + factory reset + force-stop:
   - Remove all accounts from the phone first (Settings > Accounts, incl. Google).
   - With USB debugging on, run on your computer:
       adb shell dpm set-device-owner com.example.kidguard/.AdminReceiver
   - Re-add the accounts afterwards. Reopen KidGuard in parent mode: it should
     show "Safe-mode / factory-reset lock ON".
   - Some brands (Xiaomi, Huawei, some Samsung) refuse this command.
   - To undo: parent mode > "Remove ALL protection".

## Uninstalling
Parent mode > More > "Uninstall KidGuard" drops Device Owner and device admin, then opens Android's uninstall screen.

## What survives a reboot
- Accessibility service + device admin stay enabled across normal reboots.
- BootReceiver re-applies the Device Owner locks and texts you "Phone restarted"
  and whether protection is still ON.
- Without step 7, a kid can still boot into Safe Mode (third-party apps are
  disabled there) or factory reset. Step 7 blocks both.

## Alerts
Everything is saved in the app (parent mode > Recent alerts). Only two things are TEXTED to you:
1. The kid's "Ask for more time" request (one text per request, no repeats until it is answered or 30 min pass).
2. The nudity filter.
Blocked apps/sites, new apps, restarts, tamper attempts and "service stopped" are in-app log only
(to text one of them again, pass sms = true to Alerts.send / alertOnce for that event).
Your carrier's normal SMS charges apply.

## Approving pictures, installs and uninstalls by text (v1.5)
- Nudity text now ends with a number, like P7. Reply "yes P7" to approve that picture for good (so an album
  cover isn't flagged again) or "no P7" to delete it. In parent mode, tap View, then Approve.
  Approved pictures are matched by a small fingerprint of the screen, so the same cover on the same screen is
  skipped. A different picture still gets flagged. "Forget all approved pictures" undoes it.
- The picture itself is NOT texted: only the app name, the percent and the number.
- Kid screen has "Ask to install an app" and "Ask to remove an app". You get a text like
  "Mia's phone: App request - wants to INSTALL "Roblox". Reply "yes A3" to allow or "no A3" to say no."
  - yes + install: installs open for 30 min, Play Store works during that time, and the app is
    auto-approved when it appears. Then installs lock again.
  - yes + uninstall: with Device Owner the app is removed silently; otherwise the kid can remove it
    within 15 min.
  - Requests also appear in parent mode (Allow / Say no).
- Swiping KidGuard away from recent apps ends parent mode. Pressing Home does not.

## Giving extra time
- On the kid's phone: Ask for more time > a parent enters their PIN and taps +15 / +30 / +60. Works with no texting.
- In parent mode: "Give extra time today" buttons.
- By text: reply "OK 30" / "yes 30" / just "30" from your saved number. If your phone replies with RCS / chat
  features instead of a normal SMS, Android never delivers it to KidGuard: use the PIN buttons instead.
- Phone and messaging apps are never time-limited or blocked by default (change per app in Choose apps).

## Backup layer: a separate app lock (optional but recommended)
If you skip the Device Owner step, add a separate app-lock app as a second layer.
Use it to PIN-lock Settings, the Play Store and KidGuard itself.
It is not part of KidGuard and will not stop Safe Mode or a factory reset on its own,
so it works best alongside KidGuard (ideally plus Device Owner).
This tip is also shown inside the app under "Help & tips".

## No Android Studio? Let GitHub build it
1. Create a free GitHub account and a new repository.
2. Upload the CONTENTS of this folder (not the zip) to the repo root, so
   settings.gradle.kts sits at the top. Include the .github folder.
3. Open the Actions tab > "Build KidGuard APK" > wait for the green tick.
4. Download the KidGuard-apk artifact, unzip it, and install app-debug.apk on the phone.
Optional: Settings > Pages > deploy from the main branch to show index.html as a simple site.
