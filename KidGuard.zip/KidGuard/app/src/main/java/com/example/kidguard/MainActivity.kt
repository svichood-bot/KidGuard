package com.example.kidguard

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    override fun onResume() { super.onResume(); render() }

    private var showHelp = false

    private fun render() = when {
        showHelp -> helpScreen()
        !Store.hasPin(this) -> setupScreen()
        Store.parentActive(this) -> { Hardening.apply(this); parentScreen() }
        else -> kidScreen()
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun show(vararg views: View) {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(36), dp(20), dp(20))
        }
        views.forEach { col.addView(it) }
        setContentView(ScrollView(this).apply { addView(col) })
    }
    private fun tv(t: String, sz: Float = 16f, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sz; setPadding(0, dp(8), 0, dp(8))
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
    private fun edit(hint: String, text: String, type: Int, lines: Int = 1) = EditText(this).apply {
        this.hint = hint; setText(text); inputType = type
        if (lines > 1) { minLines = lines; gravity = Gravity.TOP }
    }
    private fun pinDialog(title: String, ok: (String) -> Unit) {
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ -> ok(et.text.toString()) }
            .setNegativeButton("Cancel", null).show()
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun a11yOn() = (Settings.Secure.getString(
        contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)
    private fun adminComp() = ComponentName(this, AdminReceiver::class.java)
    private fun adminOn() =
        (getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager).isAdminActive(adminComp())

    // ---------- screens ----------
    private fun setupScreen() {
        val p1 = edit("Choose parent PIN (4-8 digits)", "",
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        val p2 = edit("Confirm PIN", "",
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        show(tv("KidGuard setup", 26f, true), tv("Create the parent PIN. Don't share it."), p1, p2,
            btn("Save PIN") {
                val a = p1.text.toString()
                if (a.length !in 4..8 || a != p2.text.toString()) toast("PINs must match (4-8 digits)")
                else { Store.setPin(this, a); Store.startParent(this); render() }
            },
            btn("Help & tips") { showHelp = true; render() })
    }

    private fun kidScreen() {
        show(tv("Kid mode", 26f, true),
            tv("Time left today: ${Store.timeLeftMin(this)} min", 20f),
            tv("Only approved websites work."),
            btn("Parent login") {
                pinDialog("Parent PIN") {
                    if (Store.checkPin(this, it)) { Store.startParent(this); render() }
                    else toast("Wrong PIN")
                }
            })
    }

    private fun parentScreen() {
        val limit = edit("Daily limit (minutes)", Store.limitMin(this).toString(), InputType.TYPE_CLASS_NUMBER)
        val allow = edit("One website per line, e.g. wikipedia.org", Store.allowText(this),
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE, 6)
        val sens = edit("Nudity filter sensitivity %", (Store.threshold(this) * 100).toInt().toString(),
            InputType.TYPE_CLASS_NUMBER)
        val phone = edit("Your mobile number for text alerts", Store.phone(this), InputType.TYPE_CLASS_PHONE)
        show(
            tv("Parent mode", 26f, true),
            tv("Auto-locks after 10 minutes.", 13f),
            tv(if (a11yOn()) "✅ Protection service ON" else "❌ Protection service OFF"),
            btn("Open Accessibility settings (enable KidGuard)") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            },
            tv(if (adminOn()) "✅ Uninstall protection ON" else "❌ Uninstall protection OFF"),
            btn("Enable uninstall protection") {
                startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComp()))
            },
            tv(if (Hardening.isOwner(this)) "✅ Safe-mode / factory-reset lock ON (Device Owner)"
               else "⚠️ Device Owner not set: safe mode and factory reset are NOT blocked. See README step 7."),
            tv("Time limit", 18f, true), limit,
            tv("Allowed websites (everything else is blocked)", 18f, true), allow,
            tv("Nudity filter (lower % = stricter)", 18f, true), sens,
            tv("Text alerts to your phone", 18f, true), phone,
            btn("Allow texting (grant SMS permission)") {
                requestPermissions(arrayOf(Manifest.permission.SEND_SMS), 1)
            },
            btn("Save settings") {
                Store.setLimitMin(this, limit.text.toString().toIntOrNull() ?: 60)
                Store.setAllowText(this, allow.text.toString())
                Store.setThreshold(this, ((sens.text.toString().toIntOrNull() ?: 70).coerceIn(10, 99)) / 100f)
                Store.setPhone(this, phone.text.toString())
                toast("Saved")
            },
            btn("Send test alert") { Alerts.send(this, "KidGuard test", "Alerts are working."); toast("Sent"); render() },
            tv("Recent alerts", 18f, true),
            tv(Store.logText(this), 13f),
            btn("Clear alert log") { Store.clearLog(this); render() },
            btn("Reset today's timer") {
                getSharedPreferences("kg", MODE_PRIVATE).edit().putLong("used", 0).apply(); toast("Reset")
            },
            btn("Remove ALL protection (release Device Owner)") {
                AlertDialog.Builder(this).setTitle("Remove protection?")
                    .setMessage("Safe mode, factory reset and uninstall will no longer be blocked.")
                    .setPositiveButton("Remove") { _, _ -> Hardening.release(this); render() }
                    .setNegativeButton("Cancel", null).show()
            },
            btn("Help & tips") { showHelp = true; render() },
            btn("Exit parent mode") { Store.endParent(this); render() }
        )
    }

    private fun helpScreen() {
        fun h(t: String) = tv(t, 18f, true)
        fun p(t: String) = tv(t, 14f)
        show(
            tv("Help & tips", 26f, true),
            h("What KidGuard does"),
            p("• Daily screen-time limit\n• Only websites you approve will open (Chrome and other browsers)\n" +
              "• Scans the screen for nudity on the phone itself (needs a model file, see README)\n" +
              "• Stops the app being uninstalled or switched off\n" +
              "• Texts you, and logs in this app, when something happens\n• Everything is enforced offline"),
            h("Setup checklist (parent mode)"),
            p("1. Enable uninstall protection\n2. Turn on KidGuard in Accessibility settings\n" +
              "3. Enter your mobile number, tap Allow texting, then Save\n4. Add allowed websites and a time limit\n" +
              "5. Send a test alert to check texts arrive"),
            h("Closing the Safe Mode / factory reset gap"),
            p("Without Device Owner, a determined kid can reboot into Safe Mode (which turns off all " +
              "third-party apps) or factory reset the phone. Device Owner blocks both. It is a one-time " +
              "step from a computer:\n" +
              "1. Remove all accounts (incl. Google) from the phone temporarily\n" +
              "2. Turn on Developer options > USB debugging, connect to a computer\n" +
              "3. Run: adb shell dpm set-device-owner com.example.kidguard/.AdminReceiver\n" +
              "4. Re-add your accounts\n" +
              "5. Reopen parent mode: it should show the Device Owner lock is ON.\n" +
              "Some brands (Xiaomi, Huawei, some Samsung) refuse this. Motorola usually works."),
            h("Tip: use a separate app lock as a backup"),
            p("If you can't or don't want to do the Device Owner step, a separate app-lock app is a good " +
              "second layer. Use it to PIN-lock Settings, the Play Store and KidGuard itself, so a kid can't " +
              "open them to remove or change anything. Note that an app lock is a different app and is not " +
              "part of KidGuard. By itself it will not stop Safe Mode or a factory reset, so it works best " +
              "alongside KidGuard, and ideally alongside the Device Owner step."),
            h("Other good habits"),
            p("• Keep your parent PIN different from the phone's screen lock\n" +
              "• Check Recent alerts in parent mode now and then\n" +
              "• A text saying 'Phone restarted - protection is OFF' means something was switched off\n" +
              "• No filter is perfect. Keep talking with your kid about what they see online"),
            btn("Back") { showHelp = false; render() }
        )
    }
}
