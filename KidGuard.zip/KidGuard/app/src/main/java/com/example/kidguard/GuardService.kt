package com.example.kidguard

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.view.inputmethod.InputMethodManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** The enforcement engine: timer, URL allowlist, uninstall/settings block, nudity scan. */
class GuardService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var scanner: NsfwScanner? = null
    private var fg = ""
    private var lastShot = 0L
    private var scanning = false
    private val lastAlert = HashMap<String, Long>()
    private val newCache = HashMap<String, Pair<Long, Boolean>>()
    private val lastFlag = java.util.concurrent.ConcurrentHashMap<String, Long>()

    private val urlIds = mapOf(
        "com.android.chrome" to listOf("com.android.chrome:id/url_bar"),
        "com.sec.android.app.sbrowser" to listOf("com.sec.android.app.sbrowser:id/location_bar_edit_text"),
        "org.mozilla.firefox" to listOf("org.mozilla.firefox:id/mozac_browser_toolbar_url_view"),
        "com.microsoft.emmx" to listOf("com.microsoft.emmx:id/url_bar"),
        "com.brave.browser" to listOf("com.brave.browser:id/url_bar"),
        "com.opera.browser" to listOf("com.opera.browser:id/url_field")
    )
    private val dialers = setOf(
        "com.google.android.dialer", "com.android.dialer",
        "com.samsung.android.dialer", "com.android.phone", "com.android.server.telecom",
        "com.android.incallui", "com.samsung.android.incallui"
    )
    // Overlays that pop up on top of KidGuard (permission prompts, system dialogs, autofill, Google services).
    // They are ignored while KidGuard's own screen is showing so typing the PIN can't trigger a "kick".
    private val overlayPkgs = setOf(
        "android", "com.google.android.permissioncontroller", "com.android.permissioncontroller",
        "com.google.android.gms", "com.google.android.googlequicksearchbox"
    )
    private var blockView: View? = null
    private var blockText: TextView? = null
    private val hideBlock = Runnable { removeBlock() }
    private var imeCache: Set<String> = emptySet()
    private var imeAt = 0L
    private fun imePkgs(): Set<String> {
        val now = System.currentTimeMillis()
        if (now - imeAt > 60_000) {
            imeCache = try {
                getSystemService(InputMethodManager::class.java).enabledInputMethodList.map { it.packageName }.toSet()
            } catch (e: Exception) { emptySet() }
            imeAt = now
        }
        return imeCache
    }

    // ---- Game ads: hidden behind a bouncing logo. The ad keeps playing underneath, so rewards still arrive. ----
    private var adView: View? = null
    private var adLogo: ImageView? = null
    private var adDx = 0f
    private var adDy = 0f
    private val hideAd = Runnable { removeAdCover() }
    private val adAnim = object : Runnable {
        override fun run() {
            val v = adView ?: return
            val logo = adLogo ?: return
            val maxX = (v.width - logo.width).toFloat()
            val maxY = (v.height - logo.height).toFloat()
            if (maxX > 0f && maxY > 0f) {
                var x = logo.x + adDx
                var y = logo.y + adDy
                if (x <= 0f) { x = 0f; adDx = Math.abs(adDx) } else if (x >= maxX) { x = maxX; adDx = -Math.abs(adDx) }
                if (y <= 0f) { y = 0f; adDy = Math.abs(adDy) } else if (y >= maxY) { y = maxY; adDy = -Math.abs(adDy) }
                logo.x = x
                logo.y = y
            }
            h.postDelayed(this, 16)
        }
    }
    // Full-screen ads open in their own screen (activity) from an ad company's code. We recognise them by that screen's name.
    private val adPrefixes = listOf(
        "com.google.android.gms.ads.", "com.google.ads.", "com.applovin.", "com.unity3d.services.ads.", "com.unity3d.ads.",
        "com.unity3d.mediation.", "com.ironsource.", "com.vungle.", "com.facebook.ads.", "com.mbridge.", "com.mintegral.",
        "com.bytedance.sdk.openadsdk.", "com.bykv.vk.openvk.", "com.chartboost.", "com.inmobi.", "com.adcolony.",
        "com.fyber.", "com.tapjoy.", "com.startapp.", "com.mopub.", "com.smaato.", "com.yandex.mobile.ads.",
        "com.amazon.device.ads.", "net.pubnative.", "com.my.target.", "com.kidoz.", "io.bidmachine.", "com.explorestack."
    )
    private fun isAdWindow(cls: String): Boolean {
        if (cls.isEmpty()) return false
        val l = cls.lowercase()
        return adPrefixes.any { l.startsWith(it) } || l.contains(".ads.") || l.endsWith("adactivity") ||
            l.contains("interstitial") || l.contains("rewardedvideo") || l.contains("rewardedad")
    }

    private val tick = object : Runnable {
        override fun run() { onTick(); h.postDelayed(this, 5000) }
    }

    // Picture check runs on its own, faster loop (about every 2 seconds) and covers EVERY app,
    // messaging apps included. Only KidGuard itself, the home screen, system UI and phone-call screens are skipped.
    private val scanTick = object : Runnable {
        override fun run() { maybeScan(); h.postDelayed(this, 2000) }
    }

    private fun maybeScan() {
        if (Build.VERSION.SDK_INT < 30 || scanner?.ready != true || scanning) return
        if (Store.parentActive(this) || MainActivity.visible) return
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isInteractive || fg.isEmpty() || fg in overlayPkgs) return
        if (fg == packageName || fg == "com.android.systemui" || fg == launcherPkg() || fg in dialers) return
        if (fg in Store.noScanApps(this)) return // parent said this app (e.g. music player) is not scanned
        if (System.currentTimeMillis() - lastShot < 1500) return
        scan()
    }

    override fun onServiceConnected() {
        scanner = NsfwScanner(this)
        if (scanner?.present != true)
            Alerts.send(this, "Nudity filter OFF", "No model file (nsfw.tflite) is inside the app, so pictures are NOT being checked.")
        else if (Build.VERSION.SDK_INT < 30)
            Alerts.send(this, "Nudity filter OFF", "This phone is Android ${Build.VERSION.RELEASE}. Screen scanning needs Android 11 or newer.")
        if (scanner?.present == true && scanner?.ready != true)
            Alerts.send(this, "Nudity filter off", "The model file in KidGuard isn't a float32 model, so it can't be used.")
        h.post(tick)
        h.post(scanTick)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        removeBlock()
        removeAdCover()
        Alerts.send(this, "KidGuard service stopped", "The accessibility service was turned off.")
        super.onDestroy()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        // Keyboards (any brand) are never "the app the kid is using".
        if (pkg.contains("inputmethod") || pkg == "com.android.systemui" || pkg in imePkgs()) return
        val winType = try { e.source?.window?.type } catch (ex: Exception) { null }
        if (winType == AccessibilityWindowInfo.TYPE_INPUT_METHOD) return
        // While KidGuard's own screen is showing, nothing else is ever blocked, so the parent can always get in
        // and type the PIN. Only the Settings / installer screens stay blocked.
        if (MainActivity.visible && pkg !in Store.BLOCKED_PKGS) return

        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) fg = pkg
        if (Store.parentActive(this) || pkg == packageName) return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val cls = e.className?.toString() ?: ""
            if (Store.coverAds(this) && isAdWindow(cls)) showAdCover(pkg, cls)
            else if (adView != null) removeAdCover() // the game (or anything else) is back on screen: the ad is over
        }

        // The home-screen app's own settings pages (e.g. Nova Settings) are locked. Its home screen is not.
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val wcls = e.className?.toString() ?: ""
            if (looksLikeSettingsScreen(wcls) && pkg != "android" && pkg == launcherPkg()) {
                Store.log(this, "Blocked home-screen settings: $pkg / $wcls")
                kick("Home screen settings are locked"); return
            }
        }

        if (pkg in Store.BLOCKED_PKGS) {
            // A parent-approved install/uninstall is in progress: let the installer screens through (never Settings).
            if (pkg in Store.INSTALLER_PKGS && Store.installerWindowOpen(this)) return
            kick("Blocked: settings / installer"); return
        }
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            if (Store.appRule(this, pkg) == 2) {
                alertOnce("blk:$pkg", "Blocked app", "Tried to open ${label(pkg)}")
                kick("${label(pkg)} is blocked"); return
            }
            if (isNewUnapproved(pkg)) {
                alertOnce("new:$pkg", "New app needs approval", "Tried to open ${label(pkg)}")
                kick("New app: ask a parent to approve it"); return
            }
        }
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && !isExempt(pkg) && Store.timeUp(this)) {
            kick("Time's up for today"); return
        }
        if (pkg in urlIds) checkUrl(pkg)
    }

    private fun onTick() {
        // Installs only stay switched on while the parent is in parent mode.
        if (!Store.parentActive(this) && Store.allowInstalls(this)) {
            Store.setAllowInstalls(this, false); Hardening.apply(this)
        }
        if (Store.windowJustExpired(this)) Hardening.apply(this) // approved install/uninstall time is over: lock again
        if (adView != null && (Store.parentActive(this) || MainActivity.visible)) removeAdCover()
        if (Store.parentActive(this)) return
        if (MainActivity.visible) return // kid or parent is looking at KidGuard itself: never kick, never count
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isInteractive || fg.isEmpty() || isExempt(fg) || fg in overlayPkgs) return // exempt = no time counting only

        Store.addUsed(this, 5000)
        if (Store.timeUp(this)) {
            alertOnce("timeup", "Screen time used up", "Daily limit reached.")
            kick("Time's up for today")
            return
        }
    }

    private fun checkUrl(pkg: String) {
        val root = rootInActiveWindow ?: return
        val text = urlIds[pkg]!!.firstNotNullOfOrNull {
            root.findAccessibilityNodeInfosByViewId(it).firstOrNull()?.text?.toString()
        } ?: return
        val host = hostOf(text) ?: return
        if (!Store.isAllowed(this, host)) {
            alertOnce("url:$host", "Blocked website", "Tried to open $host")
            kick("Site not allowed: $host")
        }
    }

    private fun hostOf(raw: String): String? {
        var s = raw.trim().lowercase()
        if (s.contains(' ') || !s.contains('.')) return null // search text / empty bar
        s = s.removePrefix("https://").removePrefix("http://")
        s = s.substringBefore('/').substringBefore('?').substringBefore(':')
        return s.removePrefix("www.").ifBlank { null }
    }

    private fun scan() {
        if (Build.VERSION.SDK_INT < 30) return
        scanning = true
        lastShot = System.currentTimeMillis()
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                if (bmp == null) { scanning = false; return }
                Thread {
                    val s = scanner?.score(bmp) ?: 0f
                    val pkgNow = fg
                    var flagId = 0
                    var approvedPic = false
                    if (s >= Store.threshold(this@GuardService) && !Store.parentActive(this@GuardService)) {
                        val hash = FlagStore.hashOf(bmp)
                        if (Store.imageApproved(this@GuardService, hash)) {
                            approvedPic = true // the parent already looked at this exact picture and said it's fine
                        } else if (System.currentTimeMillis() - (lastFlag[pkgNow] ?: 0L) > 60_000) {
                            lastFlag[pkgNow] = System.currentTimeMillis()
                            flagId = FlagStore.save(this@GuardService, bmp, pkgNow, s, hash) // private copy for the parent to review
                        }
                    }
                    h.post {
                        scanning = false
                        if (scanner?.broken == true) { scanner?.broken = false
                            alertOnce("nsfwbroken", "Nudity filter error", "The model file didn't run correctly, so scans are being skipped.") }
                        if (s >= 0.3f && s < Store.threshold(this@GuardService))
                            alertOnce("near", "Filter saw something (below your sensitivity)", "${(s * 100).toInt()}% in ${label(fg)}")
                        if (s >= Store.threshold(this@GuardService) && !approvedPic && !Store.parentActive(this@GuardService)) {
                            // Not blocked: the parent is texted (no picture is sent) and can review it in KidGuard > parent mode.
                            val how = if (flagId > 0)
                                "Reply \"yes P$flagId\" to approve this picture for good (e.g. an album cover) or \"no P$flagId\" to delete it. " +
                                "To SEE it first: KidGuard > parent mode."
                            else "On their phone open KidGuard > parent mode to review it."
                            alertOnce("nsfw", "Possible inappropriate image",
                                "${(s * 100).toInt()}% match in ${label(fg)}. $how",
                                sms = true, gapMs = 600_000)
                        }
                    }
                }.start()
            }
            override fun onFailure(errorCode: Int) { scanning = false }
        })
    }

    private fun label(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    /** True for an app installed after setup that the parent has not approved yet. */
    private fun isNewUnapproved(pkg: String): Boolean {
        val now = System.currentTimeMillis()
        newCache[pkg]?.let { if (now - it.first < 30_000) return it.second }
        val raw = try {
            val ai = packageManager.getApplicationInfo(pkg, 0)
            val system = (ai.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0
            if (system || pkg == launcherPkg() || pkg in Store.approvedApps(this) || pkg in Store.essential(this)) false
            else packageManager.getPackageInfo(pkg, 0).firstInstallTime > Store.baseline(this)
        } catch (e: Exception) { false }
        // An app the parent already said yes to installing (by name) is approved the moment it shows up.
        val result = if (raw && Store.matchesApprovedName(this, label(pkg))) { Store.approve(this, pkg); false } else raw
        newCache[pkg] = now to result
        return result
    }

    private fun isExempt(pkg: String): Boolean =
        Store.appRule(this, pkg) == 1 || pkg == packageName || pkg == "com.android.systemui" || pkg in dialers || pkg == launcherPkg()

    /** Screen (activity) names that are a settings / preferences page rather than a home screen. */
    private fun looksLikeSettingsScreen(cls: String): Boolean {
        if (cls.isEmpty()) return false
        val l = cls.lowercase()
        return l.contains("settings") || l.contains(".preferences") || l.contains("prefs") || l.contains("preference")
    }

    private fun launcherPkg(): String? = packageManager.resolveActivity(
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
    )?.activityInfo?.packageName

    private fun kick(reason: String) {
        showBlock(reason)                      // cover the screen FIRST so nothing can be touched
        performGlobalAction(GLOBAL_ACTION_HOME)
        h.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME) }, 350) // second push in case the app fought back
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** Full-screen KidGuard logo screen. Stays up ~2 seconds, absorbs every touch. */
    private fun showBlock(reason: String) {
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            if (blockView == null) {
                val root = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setBackgroundColor(Color.WHITE)
                    setPadding(dp(32), dp(32), dp(32), dp(32))
                    isClickable = true
                }
                root.addView(ImageView(this).apply {
                    setImageResource(R.drawable.kg_logo)
                    adjustViewBounds = true
                }, LinearLayout.LayoutParams(dp(230), ViewGroup.LayoutParams.WRAP_CONTENT))
                root.addView(Wordmark(this), LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
                val tv = TextView(this).apply {
                    setTextColor(Color.parseColor("#04665B")); textSize = 20f; gravity = Gravity.CENTER
                    setPadding(0, dp(16), 0, 0)
                }
                root.addView(tv)
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.OPAQUE)
                if (Build.VERSION.SDK_INT >= 28)
                    lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                wm.addView(root, lp)
                blockView = root; blockText = tv
            }
            blockText?.text = reason
            h.removeCallbacks(hideBlock)
            h.postDelayed(hideBlock, 2000)
        } catch (e: Exception) { /* never let the block screen crash the protection service */ }
    }

    private fun removeBlock() {
        try { blockView?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } } catch (e: Exception) {}
        blockView = null; blockText = null
    }

    /** Covers the ad with the bouncing logo. The top strip is left uncovered so the ad's own close button still works. */
    private fun showAdCover(pkg: String, cls: String) {
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            if (adView == null) {
                val root = FrameLayout(this).apply {
                    setBackgroundColor(Color.WHITE)
                    isClickable = true // swallows taps so the ad can't be clicked
                }
                val logo = ImageView(this).apply {
                    setImageResource(R.drawable.kg_logo)
                    adjustViewBounds = true
                }
                root.addView(logo, FrameLayout.LayoutParams(dp(120), ViewGroup.LayoutParams.WRAP_CONTENT))
                val msg = TextView(this).apply {
                    text = "\uD83C\uDFAE An ad is playing behind this screen.\nYour reward is on its way!"
                    setTextColor(Color.parseColor("#04665B")); textSize = 18f; gravity = Gravity.CENTER
                    setPadding(dp(24), 0, dp(24), dp(48))
                }
                root.addView(msg, FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
                val screenH = if (Build.VERSION.SDK_INT >= 30) wm.currentWindowMetrics.bounds.height()
                              else resources.displayMetrics.heightPixels
                val top = dp(96)
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, screenH - top,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.OPAQUE)
                lp.gravity = Gravity.TOP or Gravity.START
                lp.x = 0
                lp.y = top
                wm.addView(root, lp)
                adView = root; adLogo = logo
                adDx = dp(2).toFloat(); adDy = dp(2) * 0.8f
                h.post(adAnim)
            }
            h.removeCallbacks(hideAd)
            h.postDelayed(hideAd, 150_000) // safety: never stay up more than 2.5 minutes
            val now = System.currentTimeMillis()
            if (now - (lastAlert["ad:$pkg"] ?: 0L) > 300_000) {
                lastAlert["ad:$pkg"] = now
                Store.log(this, "Hid an ad in ${label(pkg)} ($cls)")
            }
        } catch (e: Exception) { /* never let the ad cover crash the protection service */ }
    }

    private fun removeAdCover() {
        h.removeCallbacks(adAnim)
        h.removeCallbacks(hideAd)
        try { adView?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } } catch (e: Exception) {}
        adView = null; adLogo = null
    }

    /** Logs in the app. Texts the parent only when sms = true (nudity is the only automatic text). */
    private fun alertOnce(key: String, title: String, msg: String, sms: Boolean = false, gapMs: Long = 120_000) {
        val now = System.currentTimeMillis()
        if (now - (lastAlert[key] ?: 0L) > gapMs) {
            lastAlert[key] = now
            Alerts.send(this, title, msg, sms)
        }
    }
}
