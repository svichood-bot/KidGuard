package com.example.kidguard

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/** The enforcement engine: timer, URL allowlist, uninstall/settings block, nudity scan. */
class GuardService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var scanner: NsfwScanner? = null
    private var fg = ""
    private var lastShot = 0L
    private var scanning = false
    private val lastAlert = HashMap<String, Long>()

    private val urlIds = mapOf(
        "com.android.chrome" to listOf("com.android.chrome:id/url_bar"),
        "com.sec.android.app.sbrowser" to listOf("com.sec.android.app.sbrowser:id/location_bar_edit_text"),
        "org.mozilla.firefox" to listOf("org.mozilla.firefox:id/mozac_browser_toolbar_url_view"),
        "com.microsoft.emmx" to listOf("com.microsoft.emmx:id/url_bar"),
        "com.brave.browser" to listOf("com.brave.browser:id/url_bar"),
        "com.opera.browser" to listOf("com.opera.browser:id/url_field")
    )
    private val dialers = setOf(
        "com.google.android.dialer", "com.android.dialer",
        "com.samsung.android.dialer", "com.android.phone", "com.android.server.telecom"
    )

    private val tick = object : Runnable {
        override fun run() { onTick(); h.postDelayed(this, 5000) }
    }

    override fun onServiceConnected() {
        scanner = NsfwScanner(this)
        h.post(tick)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        Alerts.send(this, "KidGuard service stopped", "The accessibility service was turned off.")
        super.onDestroy()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (pkg.contains("inputmethod") || pkg == "com.android.systemui") return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) fg = pkg
        if (Store.parentActive(this) || pkg == packageName) return

        if (pkg in Store.BLOCKED_PKGS) { kick("Blocked: settings / installer"); return }
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && !isExempt(pkg) && Store.timeUp(this)) {
            kick("Time's up for today"); return
        }
        if (pkg in urlIds) checkUrl(pkg)
    }

    private fun onTick() {
        if (Store.parentActive(this)) return
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isInteractive || fg.isEmpty() || isExempt(fg)) return

        Store.addUsed(this, 5000)
        if (Store.timeUp(this)) {
            alertOnce("timeup", "Screen time used up", "Daily limit reached.")
            kick("Time's up for today")
            return
        }
        if (Build.VERSION.SDK_INT >= 30 && scanner?.ready == true &&
            !scanning && System.currentTimeMillis() - lastShot > 4000
        ) scan()
    }

    private fun checkUrl(pkg: String) {
        val root = rootInActiveWindow ?: return
        val text = urlIds[pkg]!!.firstNotNullOfOrNull {
            root.findAccessibilityNodeInfosByViewId(it).firstOrNull()?.text?.toString()
        } ?: return
        val host = hostOf(text) ?: return
        if (!Store.isAllowed(this, host)) {
            alertOnce("url:$host", "Blocked website", "Tried to open $host")
            kick("Site not allowed: $host")
        }
    }

    private fun hostOf(raw: String): String? {
        var s = raw.trim().lowercase()
        if (s.contains(' ') || !s.contains('.')) return null // search text / empty bar
        s = s.removePrefix("https://").removePrefix("http://")
        s = s.substringBefore('/').substringBefore('?').substringBefore(':')
        return s.removePrefix("www.").ifBlank { null }
    }

    private fun scan() {
        if (Build.VERSION.SDK_INT < 30) return
        scanning = true
        lastShot = System.currentTimeMillis()
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                if (bmp == null) { scanning = false; return }
                Thread {
                    val s = scanner?.score(bmp) ?: 0f
                    h.post {
                        scanning = false
                        if (s >= Store.threshold(this@GuardService) && !Store.parentActive(this@GuardService)) {
                            alertOnce("nsfw", "Possible inappropriate image",
                                "Screen content flagged (${(s * 100).toInt()}%) in app $fg")
                            kick("Inappropriate content blocked")
                        }
                    }
                }.start()
            }
            override fun onFailure(errorCode: Int) { scanning = false }
        })
    }

    private fun isExempt(pkg: String): Boolean =
        pkg == packageName || pkg == "com.android.systemui" || pkg in dialers || pkg == launcherPkg()

    private fun launcherPkg(): String? = packageManager.resolveActivity(
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
    )?.activityInfo?.packageName

    private fun kick(reason: String) {
        performGlobalAction(GLOBAL_ACTION_HOME)
        Toast.makeText(this, reason, Toast.LENGTH_SHORT).show()
    }

    private fun alertOnce(key: String, title: String, msg: String) {
        val now = System.currentTimeMillis()
        if (now - (lastAlert[key] ?: 0L) > 120_000) {
            lastAlert[key] = now
            Alerts.send(this, title, msg)
        }
    }
}
