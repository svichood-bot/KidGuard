package com.example.kidguard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

/** Parent replies "OK 30" (or YES / MORE / ADD) from their own number to give extra minutes today. */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        if (msgs.isEmpty()) return
        val from = msgs[0].originatingAddress ?: return
        if (!Store.sameNumber(from, Store.phone(c))) return // only the parent's number counts
        val body = msgs.joinToString("") { it.messageBody ?: "" }.trim()
        val m = Regex("^(ok|yes|more|add)\\b\\s*(\\d{1,3})?", RegexOption.IGNORE_CASE).find(body) ?: return
        val mins = (m.groupValues[2].toIntOrNull() ?: 15).coerceIn(1, 240)
        Store.addBonus(c, mins)
        Alerts.send(c, "Extra time added", "+$mins min today. ${Store.timeLeftMin(c)} min left.")
    }
}
