package com.example.kidguard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

/**
 * Parent replies "OK 30" / "yes 30" / "more 30" / just "30" (also OK / YES alone = 15 min)
 * from their own number to give extra minutes today.
 * Also: "yes P7" / "no P7" approves or deletes flagged picture 7; "yes A3" / "no A3" answers the kid's install or
 * uninstall request 3. Only from the saved parent number.
 * Note: this only works if the reply arrives as a normal SMS (not RCS / chat features).
 * The in-app PIN buttons on the kid's phone always work.
 * Kill switch: "KG OFF <PIN>" / "KG PAUSE <PIN>" / "KG ON <PIN>" (see README).
 */
class SmsReceiver : BroadcastReceiver() {
    private val word = Regex("^\\W*(ok|okay|yes|yep|y|more|add|approve|approved|extra)\\b\\D{0,12}(\\d{1,3})?",
        RegexOption.IGNORE_CASE)
    private val token = Regex("\\b([PA])\\s?(\\d{1,3})\\b", RegexOption.IGNORE_CASE)
    private val yes = Regex("\\b(yes|yep|y|ok|okay|approve|approved|allow|sure)\\b", RegexOption.IGNORE_CASE)
    private val no = Regex("\\b(no|nope|n|deny|denied|decline|delete|del|reject)\\b", RegexOption.IGNORE_CASE)
    private val justNumber = Regex("^\\W*(\\d{1,3})\\s*(m|min|mins|minutes)?\\W*$", RegexOption.IGNORE_CASE)

    // Kill switch: "KG OFF 1234", "KG PAUSE 1234", "KG ON 1234" (1234 = the parent PIN), from the saved parent number only.
    private val command = Regex("^\\W*kg\\s+(kill|off|pause|on|resume)\\s+(\\d{4,8})\\W*$", RegexOption.IGNORE_CASE)

    private fun handleCommand(c: Context, from: String, cmd: String, pin: String) {
        if (!Store.sameNumber(from, Store.phone(c))) {
            Store.log(c, "Ignored a KG command from $from (not the saved parent number)"); return
        }
        if (Store.smsPinLocked(c)) { Store.log(c, "Ignored a KG command: too many wrong PINs, wait 30 min"); return }
        if (!Store.checkPin(c, pin)) {
            Store.smsPinFail(c)
            Alerts.send(c, "KG command", "Wrong PIN, nothing changed.", sms = true); return
        }
        Store.smsPinOk(c)
        when (cmd.lowercase()) {
            "kill", "off" -> {
                Hardening.release(c)            // drops Device Owner + all locks (does nothing if it isn't set)
                Store.setAllowInstalls(c, false)
                Store.setProtectionOff(c, true) // blocking, timer and scanning stop; KidGuard opens in parent mode
                Alerts.send(c, "Protection OFF", "KidGuard is fully OFF and the safe-mode lock is released. Text KG ON <PIN> to turn it back on.", sms = true)
            }
            "pause" -> {
                Store.startParentFor(c, 120)
                Alerts.send(c, "Paused", "All blocking is OFF for 2 hours, then it turns back on by itself. Text KG ON <PIN> to end it early.", sms = true)
            }
            else -> { // on / resume
                Store.setProtectionOff(c, false)
                Store.endParent(c)
                Hardening.apply(c)
                Alerts.send(c, "Protection ON", "KidGuard is blocking again. Safe-mode lock is " +
                    (if (Hardening.isOwner(c)) "ON." else "off (re-run the adb Device Owner step to turn it on)."), sms = true)
            }
        }
    }

    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        if (msgs.isEmpty()) return
        val from = msgs[0].originatingAddress ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }.trim()

        command.matchEntire(body)?.let { handleCommand(c, from, it.groupValues[1], it.groupValues[2]); return }

        // ---- Answers to a picture / app request: "yes P7", "no P7", "yes A3", "no A3" ----
        token.find(body)?.let { t ->
            val kind = t.groupValues[1].uppercase()
            val id = t.groupValues[2].toIntOrNull() ?: return@let
            val flag = if (kind == "P") FlagStore.find(c, id) else null
            val req = if (kind == "A") Store.findRequest(c, id) else null
            if (flag == null && req == null) return@let // no such waiting item: maybe it's a time reply, keep going
            if (!Store.sameNumber(from, Store.phone(c))) {
                Store.log(c, "Ignored a text about $kind$id from $from (not the saved parent number)")
                return
            }
            val isYes = yes.containsMatchIn(body)
            val isNo = no.containsMatchIn(body)
            if (isYes == isNo) return // neither, or both: unclear, do nothing
            val reply: String = if (flag != null) {
                if (isYes) {
                    if (FlagStore.approve(c, flag)) { Store.log(c, "Parent approved picture P$id by text."); "Picture P$id approved. It won't be flagged again." }
                    else "Couldn't approve P$id (older saved picture). Use KidGuard > parent mode."
                } else { FlagStore.delete(flag.file); Store.log(c, "Parent deleted picture P$id by text."); "Picture P$id deleted." }
            } else if (isYes) Requests.approve(c, req!!) else Requests.decline(c, req!!)
            Alerts.send(c, "Done", reply, sms = true)
            return
        }

        val mins: Int = word.find(body)?.let { (it.groupValues[2].toIntOrNull() ?: 15) }
            ?: justNumber.find(body)?.groupValues?.get(1)?.toIntOrNull()
            ?: return // not an approval text, ignore silently
        // A bare "ok"/"yes" (no number) only counts while a request is waiting, so normal chat can't hand out time.
        if (body.none { it.isDigit() } && !Store.requestPending(c)) return

        if (!Store.sameNumber(from, Store.phone(c))) {
            Store.log(c, "Ignored an approval-looking text from $from (not the saved parent number)")
            return
        }
        val m = mins.coerceIn(1, 240)
        Store.addBonus(c, m)
        Store.log(c, "Parent approved +$m min by text. ${Store.timeLeftMin(c)} min left.") // log only, no extra text
    }
}
