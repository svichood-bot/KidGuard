package com.example.kidguard

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.provider.Telephony
import android.telecom.TelecomManager
import java.security.MessageDigest
import java.time.LocalDate
import org.json.JSONObject

object Store {
    // Screens a kid must not reach (stops disabling the service / uninstalling).
    val BLOCKED_PKGS = setOf(
        "com.android.settings",
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.samsung.android.packageinstaller"
    )

    private fun sp(c: Context) = c.getSharedPreferences("kg", Context.MODE_PRIVATE)

    private fun hash(pin: String): String =
        MessageDigest.getInstance("SHA-256").digest("kg-salt-$pin".toByteArray())
            .joinToString("") { "%02x".format(it) }

    // ---- PIN / parent mode ----
    fun hasPin(c: Context) = sp(c).contains("pin")
    fun setPin(c: Context, pin: String) =
        sp(c).edit().putString("pin", hash(pin)).putLong("baseline", System.currentTimeMillis()).apply()
    fun checkPin(c: Context, pin: String) = sp(c).getString("pin", null) == hash(pin)
    fun parentActive(c: Context) = System.currentTimeMillis() < sp(c).getLong("parentUntil", 0)
    fun startParent(c: Context) =
        sp(c).edit().putLong("parentUntil", System.currentTimeMillis() + 10 * 60 * 1000).apply()
    fun endParent(c: Context) = sp(c).edit().putLong("parentUntil", 0).apply()

    // ---- Timer ----
    fun limitMin(c: Context) = sp(c).getInt("limit", 60)
    fun setLimitMin(c: Context, m: Int) = sp(c).edit().putInt("limit", m).apply()

    private fun rollover(c: Context) {
        val today = LocalDate.now().toString()
        if (sp(c).getString("day", "") != today)
            sp(c).edit().putString("day", today).putLong("used", 0).putInt("bonus", 0).apply()
    }
    fun usedMs(c: Context): Long { rollover(c); return sp(c).getLong("used", 0) }
    fun addUsed(c: Context, ms: Long) { val u = usedMs(c); sp(c).edit().putLong("used", u + ms).apply() }
    fun bonusMin(c: Context): Int { rollover(c); return sp(c).getInt("bonus", 0) }
    fun addBonus(c: Context, m: Int) { val b = bonusMin(c); sp(c).edit().putInt("bonus", b + m).apply() }
    fun totalMin(c: Context) = limitMin(c) + bonusMin(c)
    fun timeUp(c: Context) = usedMs(c) >= totalMin(c) * 60_000L
    fun timeLeftMin(c: Context) = maxOf(0L, totalMin(c) - usedMs(c) / 60_000L)
    fun lastRequest(c: Context) = sp(c).getLong("lastReq", 0)
    fun markRequest(c: Context) = sp(c).edit()
        .putLong("lastReq", System.currentTimeMillis()).putInt("reqTotal", totalMin(c)).apply()
    /** A time request is "pending" until time is granted (total goes up) or 30 minutes pass: only ONE text per request. */
    fun requestPending(c: Context): Boolean {
        val t = lastRequest(c)
        return t > 0 && System.currentTimeMillis() - t < 30 * 60_000L && totalMin(c) == sp(c).getInt("reqTotal", -1)
    }
    fun sameNumber(a: String, b: String): Boolean {
        val x = a.filter { it.isDigit() }; val y = b.filter { it.isDigit() }
        return x.length >= 6 && y.length >= 6 && (x.takeLast(9) == y.takeLast(9))
    }

    // ---- Website allowlist (empty = everything blocked) ----
    fun allowText(c: Context) = sp(c).getString("allow", "") ?: ""
    fun setAllowText(c: Context, t: String) = sp(c).edit().putString("allow", t).apply()
    fun allowList(c: Context) = allowText(c).lines().map { it.trim().lowercase() }.filter { it.isNotBlank() }
    fun isAllowed(c: Context, host: String): Boolean =
        allowList(c).any { host == it || host.endsWith(".$it") }

    // ---- Nudity filter sensitivity (0.0-1.0) ----
    fun threshold(c: Context) = sp(c).getFloat("thr", 0.7f)
    fun setThreshold(c: Context, t: Float) = sp(c).edit().putFloat("thr", t).apply()

    // ---- Alerts: parent phone number + in-app log ----
    fun phone(c: Context) = sp(c).getString("phone", "") ?: ""
    fun setPhone(c: Context, p: String) = sp(c).edit().putString("phone", p.trim()).apply()
    fun lastSms(c: Context) = sp(c).getLong("lastSms", 0)
    fun markSms(c: Context) = sp(c).edit().putLong("lastSms", System.currentTimeMillis()).apply()

    // ---- Per-app rules: 0 = normal (time limit), 1 = no time limit, 2 = blocked ----
    // Phone + SMS apps default to "no time limit" unless the parent explicitly picks something else.
    private fun strSet(c: Context, k: String): Set<String> = sp(c).getStringSet(k, emptySet()) ?: emptySet()
    private fun putSet(c: Context, k: String, s: Set<String>) = sp(c).edit().putStringSet(k, HashSet(s)).apply()
    fun appRule(c: Context, pkg: String): Int = when {
        pkg in strSet(c, "blockedApps") -> 2
        pkg in strSet(c, "freeApps") -> 1
        pkg in strSet(c, "normalApps") -> 0
        pkg in essential(c) -> 1
        else -> 0
    }
    fun setAppRule(c: Context, pkg: String, rule: Int) {
        putSet(c, "blockedApps", strSet(c, "blockedApps") - pkg)
        putSet(c, "freeApps", strSet(c, "freeApps") - pkg)
        putSet(c, "normalApps", strSet(c, "normalApps") - pkg)
        when (rule) {
            2 -> putSet(c, "blockedApps", strSet(c, "blockedApps") + pkg)
            1 -> putSet(c, "freeApps", strSet(c, "freeApps") + pkg)
            else -> putSet(c, "normalApps", strSet(c, "normalApps") + pkg)
        }
    }

    // ---- Phone + messaging apps (never limited or blocked by default) ----
    private var essCache: Set<String> = emptySet()
    private var essAt = 0L
    private val essNames = listOf(
        "com.google.android.dialer", "com.android.dialer", "com.samsung.android.dialer",
        "com.android.phone", "com.android.server.telecom", "com.android.incallui",
        "com.samsung.android.incallui", "com.android.mms", "com.android.messaging",
        "com.google.android.apps.messaging", "com.samsung.android.messaging",
        "com.motorola.messaging", "com.android.contacts", "com.google.android.contacts",
        "com.samsung.android.app.contacts"
    )
    fun essential(c: Context): Set<String> {
        val now = System.currentTimeMillis()
        if (essCache.isNotEmpty() && now - essAt < 60_000) return essCache
        val s = HashSet<String>()
        val pm = c.packageManager
        fun isSystem(pkg: String) = try {
            val f = pm.getApplicationInfo(pkg, 0).flags
            (f and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0
        } catch (e: Exception) { false }
        try { c.getSystemService(TelecomManager::class.java)?.defaultDialerPackage?.let { s.add(it) } } catch (e: Exception) {}
        try { Telephony.Sms.getDefaultSmsPackage(c)?.let { s.add(it) } } catch (e: Exception) {}
        try {
            listOf(Intent(Intent.ACTION_DIAL, Uri.parse("tel:123")),
                   Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:123"))).forEach { i ->
                pm.queryIntentActivities(i, 0).forEach { ri ->
                    val p = ri.activityInfo.packageName
                    if (isSystem(p)) s.add(p)
                }
            }
        } catch (e: Exception) {}
        essNames.forEach { if (isSystem(it)) s.add(it) }
        essCache = s; essAt = now
        return s
    }

    // ---- New apps stay locked until the parent approves them ----
    fun approvedApps(c: Context): Set<String> = strSet(c, "approved")
    fun approve(c: Context, pkg: String) = putSet(c, "approved", strSet(c, "approved") + pkg)
    fun baseline(c: Context): Long {
        val b = sp(c).getLong("baseline", 0)
        if (b > 0) return b
        val n = System.currentTimeMillis()
        sp(c).edit().putLong("baseline", n).apply()
        return n
    }

    // ---- Parent can temporarily allow installs (re-locks when parent mode ends) ----
    fun allowInstalls(c: Context) = sp(c).getBoolean("allowInst", false)
    fun setAllowInstalls(c: Context, v: Boolean) = sp(c).edit().putBoolean("allowInst", v).apply()

    // ---- Child's name (shown on the kid screen and in every text) ----
    fun childName(c: Context) = sp(c).getString("child", "") ?: ""
    fun setChildName(c: Context, n: String) = sp(c).edit().putString("child", n.trim()).apply()

    // ---- Copy settings between phones (PIN and child's name are NOT copied) ----
    fun exportJson(c: Context): String = JSONObject()
        .put("app", "KidGuard").put("version", 1)
        .put("limit", limitMin(c)).put("allow", allowText(c))
        .put("threshold", threshold(c).toDouble()).put("phone", phone(c))
        .toString(2)

    fun importJson(c: Context, text: String): Boolean = try {
        val j = JSONObject(text)
        if (j.optString("app") != "KidGuard") false
        else {
            if (j.has("limit")) setLimitMin(c, j.getInt("limit").coerceIn(1, 1440))
            if (j.has("allow")) setAllowText(c, j.getString("allow"))
            if (j.has("threshold")) setThreshold(c, j.getDouble("threshold").toFloat().coerceIn(0.1f, 0.99f))
            if (j.has("phone")) setPhone(c, j.getString("phone"))
            true
        }
    } catch (e: Exception) { false }

    fun log(c: Context, line: String) {
        val stamp = java.time.LocalDateTime.now().toString().take(16).replace('T', ' ')
        val old = (sp(c).getString("log", "") ?: "").lines().filter { it.isNotBlank() }
        sp(c).edit().putString("log", (listOf("$stamp  $line") + old).take(50).joinToString("\n")).apply()
    }
    fun logText(c: Context) = (sp(c).getString("log", "") ?: "").ifBlank { "(no alerts yet)" }
    fun clearLog(c: Context) = sp(c).edit().putString("log", "").apply()
}
