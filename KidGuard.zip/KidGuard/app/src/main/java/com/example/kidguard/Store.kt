package com.example.kidguard

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.provider.Telephony
import android.telecom.TelecomManager
import java.security.MessageDigest
import java.time.LocalDate
import org.json.JSONArray
import org.json.JSONObject

object Store {
    // Screens a kid must not reach (stops disabling the service / uninstalling).
    val BLOCKED_PKGS = setOf(
        "com.android.settings",
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.samsung.android.packageinstaller"
    )

    /** Installer screens only (Settings stays blocked always). Allowed while an approved install/uninstall window is open. */
    val INSTALLER_PKGS = setOf(
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.samsung.android.packageinstaller"
    )
    private const val PLAY = "com.android.vending"

    private fun sp(c: Context) = c.getSharedPreferences("kg", Context.MODE_PRIVATE)

    private fun hash(pin: String): String =
        MessageDigest.getInstance("SHA-256").digest("kg-salt-$pin".toByteArray())
            .joinToString("") { "%02x".format(it) }

    // ---- PIN / parent mode ----
    fun hasPin(c: Context) = sp(c).contains("pin")
    fun setPin(c: Context, pin: String) =
        sp(c).edit().putString("pin", hash(pin)).putLong("baseline", System.currentTimeMillis()).apply()
    fun checkPin(c: Context, pin: String) = sp(c).getString("pin", null) == hash(pin)
    fun parentActive(c: Context) = protectionOff(c) || System.currentTimeMillis() < sp(c).getLong("parentUntil", 0)
    fun startParentFor(c: Context, minutes: Int) =
        sp(c).edit().putLong("parentUntil", System.currentTimeMillis() + minutes * 60_000L).commit()

    // ---- Text-message kill switch ("KG OFF <PIN>" / "KG PAUSE <PIN>" / "KG ON <PIN>") ----
    // While "off" is set every check behaves as if a parent is logged in, until "KG ON <PIN>" is texted.
    fun protectionOff(c: Context) = sp(c).getBoolean("protOff", false)
    fun setProtectionOff(c: Context, off: Boolean) = sp(c).edit().putBoolean("protOff", off).commit()
    private const val SMS_FAIL_WINDOW = 30 * 60 * 1000L
    fun smsPinLocked(c: Context) =
        sp(c).getInt("smsFails", 0) >= 5 && System.currentTimeMillis() - sp(c).getLong("smsFailAt", 0) < SMS_FAIL_WINDOW
    fun smsPinFail(c: Context) {
        val now = System.currentTimeMillis()
        val n = if (now - sp(c).getLong("smsFailAt", 0) > SMS_FAIL_WINDOW) 1 else sp(c).getInt("smsFails", 0) + 1
        sp(c).edit().putInt("smsFails", n).putLong("smsFailAt", now).apply()
    }
    fun smsPinOk(c: Context) = sp(c).edit().putInt("smsFails", 0).apply()
    fun startParent(c: Context) =
        sp(c).edit().putLong("parentUntil", System.currentTimeMillis() + 10 * 60 * 1000).apply()
    // commit() (not apply) so it is saved even if the app process is killed right after a swipe-away
    fun endParent(c: Context) = sp(c).edit().putLong("parentUntil", 0).commit()

    // ---- Timer ----
    fun limitMin(c: Context) = sp(c).getInt("limit", 60)
    fun setLimitMin(c: Context, m: Int) = sp(c).edit().putInt("limit", m).apply()

    private fun rollover(c: Context) {
        val today = LocalDate.now().toString()
        if (sp(c).getString("day", "") != today)
            sp(c).edit().putString("day", today).putLong("used", 0).putInt("bonus", 0).apply()
    }
    fun usedMs(c: Context): Long { rollover(c); return sp(c).getLong("used", 0) }
    fun addUsed(c: Context, ms: Long) { val u = usedMs(c); sp(c).edit().putLong("used", u + ms).apply() }
    fun bonusMin(c: Context): Int { rollover(c); return sp(c).getInt("bonus", 0) }
    fun addBonus(c: Context, m: Int) { val b = bonusMin(c); sp(c).edit().putInt("bonus", b + m).apply() }
    fun totalMin(c: Context) = limitMin(c) + bonusMin(c)
    fun timeUp(c: Context) = usedMs(c) >= totalMin(c) * 60_000L
    fun timeLeftMin(c: Context) = maxOf(0L, totalMin(c) - usedMs(c) / 60_000L)
    fun lastRequest(c: Context) = sp(c).getLong("lastReq", 0)
    fun markRequest(c: Context) = sp(c).edit()
        .putLong("lastReq", System.currentTimeMillis()).putInt("reqTotal", totalMin(c)).apply()
    /** A time request is "pending" until time is granted (total goes up) or 30 minutes pass: only ONE text per request. */
    fun requestPending(c: Context): Boolean {
        val t = lastRequest(c)
        return t > 0 && System.currentTimeMillis() - t < 30 * 60_000L && totalMin(c) == sp(c).getInt("reqTotal", -1)
    }
    fun sameNumber(a: String, b: String): Boolean {
        val x = a.filter { it.isDigit() }; val y = b.filter { it.isDigit() }
        return x.length >= 6 && y.length >= 6 && (x.takeLast(9) == y.takeLast(9))
    }

    // ---- Website allowlist (empty = everything blocked) ----
    fun allowText(c: Context) = sp(c).getString("allow", "") ?: ""
    fun setAllowText(c: Context, t: String) = sp(c).edit().putString("allow", t).apply()
    fun allowList(c: Context) = allowText(c).lines().map { it.trim().lowercase() }.filter { it.isNotBlank() }
    fun isAllowed(c: Context, host: String): Boolean =
        allowList(c).any { host == it || host.endsWith(".$it") }

    // ---- Nudity filter sensitivity (0.0-1.0) ----
    fun threshold(c: Context) = sp(c).getFloat("thr", 0.7f)
    fun setThreshold(c: Context, t: Float) = sp(c).edit().putFloat("thr", t).apply()

    // ---- Alerts: parent phone number + in-app log ----
    fun phone(c: Context) = sp(c).getString("phone", "") ?: ""
    fun setPhone(c: Context, p: String) = sp(c).edit().putString("phone", p.trim()).apply()
    fun lastSms(c: Context) = sp(c).getLong("lastSms", 0)
    fun markSms(c: Context) = sp(c).edit().putLong("lastSms", System.currentTimeMillis()).apply()

    // ---- Per-app rules: 0 = normal (time limit), 1 = no time limit, 2 = blocked ----
    // Phone + SMS apps default to "no time limit" unless the parent explicitly picks something else.
    private fun strSet(c: Context, k: String): Set<String> = sp(c).getStringSet(k, emptySet()) ?: emptySet()
    private fun putSet(c: Context, k: String, s: Set<String>) = sp(c).edit().putStringSet(k, HashSet(s)).apply()
    fun appRule(c: Context, pkg: String): Int = when {
        pkg in strSet(c, "blockedApps") -> 2
        pkg == PLAY && installWindowOpen(c) -> 1 // parent said yes to an install: Play Store works for a while
        pkg in strSet(c, "freeApps") -> 1
        pkg in strSet(c, "normalApps") -> 0
        pkg in essential(c) -> 1
        pkg == c.packageName || pkg in systemOk || pkg in homePkgs(c) -> 1
        pkg !in launchablePkgs(c) -> 1 // no home-screen icon = a hidden system helper (pop-up, picker...), never blocked
        else -> 2 // every app with an icon is BLOCKED until the parent allows it
    }

    private var launchCache: Set<String> = emptySet()
    private var launchAt = 0L
    private fun launchablePkgs(c: Context): Set<String> {
        val now = System.currentTimeMillis()
        if (launchCache.isNotEmpty() && now - launchAt < 60_000) return launchCache
        launchCache = try {
            c.packageManager.queryIntentActivities(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
            ).map { it.activityInfo.packageName }.toSet()
        } catch (e: Exception) { emptySet() }
        launchAt = now
        return launchCache
    }

    // Parts of the phone that must always work (pop-ups, home screen, KidGuard itself).
    private val systemOk = setOf(
        "android", "com.android.systemui", "com.google.android.gms", "com.google.android.gsf",
        "com.google.android.permissioncontroller", "com.android.permissioncontroller",
        "com.android.providers.telephony", "com.android.server.telecom"
    )
    private var homeCache: Set<String> = emptySet()
    private var homeAt = 0L
    private fun homePkgs(c: Context): Set<String> {
        val now = System.currentTimeMillis()
        if (homeCache.isNotEmpty() && now - homeAt < 60_000) return homeCache
        homeCache = try {
            c.packageManager.queryIntentActivities(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
            ).map { it.activityInfo.packageName }.toSet()
        } catch (e: Exception) { emptySet() }
        homeAt = now
        return homeCache
    }

    fun setAppRule(c: Context, pkg: String, rule: Int) {
        if (rule != 2) approve(c, pkg) // allowing an app also approves it
        putSet(c, "blockedApps", strSet(c, "blockedApps") - pkg)
        putSet(c, "freeApps", strSet(c, "freeApps") - pkg)
        putSet(c, "normalApps", strSet(c, "normalApps") - pkg)
        when (rule) {
            2 -> putSet(c, "blockedApps", strSet(c, "blockedApps") + pkg)
            1 -> putSet(c, "freeApps", strSet(c, "freeApps") + pkg)
            else -> putSet(c, "normalApps", strSet(c, "normalApps") + pkg)
        }
    }

    // ---- Phone + messaging apps (never limited or blocked by default) ----
    private var essCache: Set<String> = emptySet()
    private var essAt = 0L
    private val essNames = listOf(
        "com.google.android.dialer", "com.android.dialer", "com.samsung.android.dialer",
        "com.android.phone", "com.android.server.telecom", "com.android.incallui",
        "com.samsung.android.incallui", "com.android.mms", "com.android.messaging",
        "com.google.android.apps.messaging", "com.samsung.android.messaging",
        "com.motorola.messaging", "com.android.contacts", "com.google.android.contacts",
        "com.samsung.android.app.contacts"
    )
    fun essential(c: Context): Set<String> {
        val now = System.currentTimeMillis()
        if (essCache.isNotEmpty() && now - essAt < 60_000) return essCache
        val s = HashSet<String>()
        val pm = c.packageManager
        fun isSystem(pkg: String) = try {
            val f = pm.getApplicationInfo(pkg, 0).flags
            (f and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0
        } catch (e: Exception) { false }
        try { c.getSystemService(TelecomManager::class.java)?.defaultDialerPackage?.let { s.add(it) } } catch (e: Exception) {}
        try { Telephony.Sms.getDefaultSmsPackage(c)?.let { s.add(it) } } catch (e: Exception) {}
        try {
            listOf(Intent(Intent.ACTION_DIAL, Uri.parse("tel:123")),
                   Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:123"))).forEach { i ->
                pm.queryIntentActivities(i, 0).forEach { ri ->
                    val p = ri.activityInfo.packageName
                    if (isSystem(p)) s.add(p)
                }
            }
        } catch (e: Exception) {}
        essNames.forEach { if (isSystem(it)) s.add(it) }
        essCache = s; essAt = now
        return s
    }

    // ---- New apps stay locked until the parent approves them ----
    fun approvedApps(c: Context): Set<String> = strSet(c, "approved")
    fun approve(c: Context, pkg: String) = putSet(c, "approved", strSet(c, "approved") + pkg)
    fun baseline(c: Context): Long {
        val b = sp(c).getLong("baseline", 0)
        if (b > 0) return b
        val n = System.currentTimeMillis()
        sp(c).edit().putLong("baseline", n).apply()
        return n
    }

    // ---- Parent can temporarily allow installs (re-locks when parent mode ends) ----
    fun allowInstalls(c: Context) = sp(c).getBoolean("allowInst", false)
    fun setAllowInstalls(c: Context, v: Boolean) = sp(c).edit().putBoolean("allowInst", v).apply()

    // ---- Game ads: covered by a bouncing logo (the ad still plays underneath, so rewards still arrive) ----
    fun coverAds(c: Context) = sp(c).getBoolean("coverAds", true)
    fun setCoverAds(c: Context, v: Boolean) = sp(c).edit().putBoolean("coverAds", v).apply()

    // ---- Approved pictures (so e.g. an album cover isn't flagged again) ----
    private fun hexToLong(s: String): Long? = try { java.lang.Long.parseUnsignedLong(s, 16) } catch (e: Exception) { null }
    /** Close enough (<= 8 of 64 bits different) to a picture the parent approved. */
    fun imageApproved(c: Context, h: Long): Boolean =
        strSet(c, "okImages").any { s -> hexToLong(s)?.let { java.lang.Long.bitCount(it xor h) <= 8 } ?: false }
    /** Apps the parent chose not to picture-scan at all (e.g. a music player full of album covers). */
    fun noScanApps(c: Context): Set<String> = strSet(c, "noScan")
    fun setNoScan(c: Context, pkg: String, on: Boolean) =
        putSet(c, "noScan", if (on) strSet(c, "noScan") + pkg else strSet(c, "noScan") - pkg)
    fun approveImage(c: Context, h: Long) = putSet(c, "okImages", strSet(c, "okImages") + java.lang.Long.toHexString(h))
    fun approvedImageCount(c: Context) = strSet(c, "okImages").size
    fun clearApprovedImages(c: Context) = putSet(c, "okImages", emptySet())

    // ---- Kid's install / uninstall requests (answered by text "yes A3" / "no A3" or in parent mode) ----
    class Req(val id: Int, val type: String, val name: String, val pkg: String, val time: Long)

    fun requests(c: Context): List<Req> = try {
        val a = JSONArray(sp(c).getString("reqs", "[]"))
        val now = System.currentTimeMillis()
        (0 until a.length()).map { a.getJSONObject(it) }
            .map { Req(it.getInt("id"), it.getString("type"), it.getString("name"), it.optString("pkg"), it.getLong("time")) }
            .filter { now - it.time < 24L * 60 * 60 * 1000 }
    } catch (e: Exception) { emptyList() }

    private fun saveRequests(c: Context, l: List<Req>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("type", it.type).put("name", it.name).put("pkg", it.pkg).put("time", it.time)) }
        sp(c).edit().putString("reqs", a.toString()).apply()
    }

    /** Returns the new request number, or null if the same request is already waiting. */
    fun addRequest(c: Context, type: String, name: String, pkg: String): Int? {
        val cur = requests(c)
        if (cur.any { it.type == type && it.name.equals(name, true) }) return null
        val id = (sp(c).getInt("reqSeq", 0) % 999) + 1
        sp(c).edit().putInt("reqSeq", id).apply()
        saveRequests(c, cur.filter { it.id != id } + Req(id, type, name, pkg, System.currentTimeMillis()))
        return id
    }
    fun findRequest(c: Context, id: Int): Req? = requests(c).firstOrNull { it.id == id }
    fun removeRequest(c: Context, id: Int) = saveRequests(c, requests(c).filter { it.id != id })

    // ---- Short, parent-approved windows for installing / uninstalling ----
    fun installWindowOpen(c: Context) = System.currentTimeMillis() < sp(c).getLong("instUntil", 0)
    fun uninstallWindowOpen(c: Context) = System.currentTimeMillis() < sp(c).getLong("uninstUntil", 0)
    fun installerWindowOpen(c: Context) = installWindowOpen(c) || uninstallWindowOpen(c)
    fun openInstallWindow(c: Context, min: Int) = sp(c).edit().putLong("instUntil", System.currentTimeMillis() + min * 60_000L).apply()
    fun openUninstallWindow(c: Context, min: Int) = sp(c).edit().putLong("uninstUntil", System.currentTimeMillis() + min * 60_000L).apply()
    /** True once, right after a window has run out, so the locks can be re-applied. */
    fun windowJustExpired(c: Context): Boolean {
        val now = System.currentTimeMillis()
        var hit = false
        val e = sp(c).edit()
        for (k in listOf("instUntil", "uninstUntil")) {
            val t = sp(c).getLong(k, 0)
            if (t in 1 until now) { e.putLong(k, 0); hit = true }
        }
        e.apply()
        return hit
    }
    /** Apps the parent said yes to installing: when one shows up it is approved automatically. */
    fun addApprovedName(c: Context, n: String) = putSet(c, "okNames", strSet(c, "okNames") + n.trim().lowercase())
    fun matchesApprovedName(c: Context, label: String): Boolean {
        val l = label.trim().lowercase()
        return strSet(c, "okNames").any { it.length >= 3 && l.contains(it) }
    }

    // ---- Child's name (shown on the kid screen and in every text) ----
    fun childName(c: Context) = sp(c).getString("child", "") ?: ""
    fun setChildName(c: Context, n: String) = sp(c).edit().putString("child", n.trim()).apply()

    // ---- Copy settings between phones or after a reinstall (the PIN is NOT copied) ----
    fun exportJson(c: Context): String = JSONObject()
        .put("app", "KidGuard").put("version", 2)
        .put("limit", limitMin(c)).put("allow", allowText(c))
        .put("threshold", threshold(c).toDouble()).put("phone", phone(c))
        .put("child", childName(c))
        .put("coverAds", coverAds(c))
        .put("blockedApps", JSONArray(strSet(c, "blockedApps").toList()))
        .put("freeApps", JSONArray(strSet(c, "freeApps").toList()))
        .put("normalApps", JSONArray(strSet(c, "normalApps").toList()))
        .put("approved", JSONArray(strSet(c, "approved").toList()))
        .put("okImages", JSONArray(strSet(c, "okImages").toList()))
        .put("noScan", JSONArray(strSet(c, "noScan").toList()))
        .toString(2)

    fun importJson(c: Context, text: String): Boolean = try {
        val j = JSONObject(text)
        if (j.optString("app") != "KidGuard") false
        else {
            if (j.has("limit")) setLimitMin(c, j.getInt("limit").coerceIn(1, 1440))
            if (j.has("allow")) setAllowText(c, j.getString("allow"))
            if (j.has("threshold")) setThreshold(c, j.getDouble("threshold").toFloat().coerceIn(0.1f, 0.99f))
            if (j.has("phone")) setPhone(c, j.getString("phone"))
            if (j.has("child")) setChildName(c, j.getString("child"))
            if (j.has("coverAds")) setCoverAds(c, j.getBoolean("coverAds"))
            fun arr(k: String): Set<String>? = j.optJSONArray(k)?.let { a -> (0 until a.length()).map { a.getString(it) }.toSet() }
            arr("blockedApps")?.let { putSet(c, "blockedApps", it) }
            arr("freeApps")?.let { putSet(c, "freeApps", it) }
            arr("normalApps")?.let { putSet(c, "normalApps", it) }
            arr("approved")?.let { putSet(c, "approved", it) }
            arr("okImages")?.let { putSet(c, "okImages", it) }
            arr("noScan")?.let { putSet(c, "noScan", it) }
            true
        }
    } catch (e: Exception) { false }

    fun log(c: Context, line: String) {
        val stamp = java.time.LocalDateTime.now().toString().take(16).replace('T', ' ')
        val old = (sp(c).getString("log", "") ?: "").lines().filter { it.isNotBlank() }
        sp(c).edit().putString("log", (listOf("$stamp  $line") + old).take(50).joinToString("\n")).apply()
    }
    fun logText(c: Context) = (sp(c).getString("log", "") ?: "").ifBlank { "(no alerts yet)" }
    fun clearLog(c: Context) = sp(c).edit().putString("log", "").apply()
}
