package com.example.kidguard

import android.content.Context
import java.security.MessageDigest
import java.time.LocalDate
import java.util.UUID

object Store {
    // Screens a kid must not reach (stops disabling the service / uninstalling).
    val BLOCKED_PKGS = setOf(
        "com.android.settings",
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.samsung.android.packageinstaller"
    )

    private fun sp(c: Context) = c.getSharedPreferences("kg", Context.MODE_PRIVATE)

    private fun hash(pin: String): String =
        MessageDigest.getInstance("SHA-256").digest("kg-salt-$pin".toByteArray())
            .joinToString("") { "%02x".format(it) }

    // ---- PIN / parent mode ----
    fun hasPin(c: Context) = sp(c).contains("pin")
    fun setPin(c: Context, pin: String) = sp(c).edit().putString("pin", hash(pin)).apply()
    fun checkPin(c: Context, pin: String) = sp(c).getString("pin", null) == hash(pin)
    fun parentActive(c: Context) = System.currentTimeMillis() < sp(c).getLong("parentUntil", 0)
    fun startParent(c: Context) =
        sp(c).edit().putLong("parentUntil", System.currentTimeMillis() + 10 * 60 * 1000).apply()
    fun endParent(c: Context) = sp(c).edit().putLong("parentUntil", 0).apply()

    // ---- Timer ----
    fun limitMin(c: Context) = sp(c).getInt("limit", 60)
    fun setLimitMin(c: Context, m: Int) = sp(c).edit().putInt("limit", m).apply()

    private fun rollover(c: Context) {
        val today = LocalDate.now().toString()
        if (sp(c).getString("day", "") != today)
            sp(c).edit().putString("day", today).putLong("used", 0).apply()
    }
    fun usedMs(c: Context): Long { rollover(c); return sp(c).getLong("used", 0) }
    fun addUsed(c: Context, ms: Long) { val u = usedMs(c); sp(c).edit().putLong("used", u + ms).apply() }
    fun timeUp(c: Context) = usedMs(c) >= limitMin(c) * 60_000L
    fun timeLeftMin(c: Context) = maxOf(0L, limitMin(c) - usedMs(c) / 60_000L)

    // ---- Website allowlist (empty = everything blocked) ----
    fun allowText(c: Context) = sp(c).getString("allow", "") ?: ""
    fun setAllowText(c: Context, t: String) = sp(c).edit().putString("allow", t).apply()
    fun allowList(c: Context) = allowText(c).lines().map { it.trim().lowercase() }.filter { it.isNotBlank() }
    fun isAllowed(c: Context, host: String): Boolean =
        allowList(c).any { host == it || host.endsWith(".$it") }

    // ---- Nudity filter sensitivity (0.0-1.0) ----
    fun threshold(c: Context) = sp(c).getFloat("thr", 0.7f)
    fun setThreshold(c: Context, t: Float) = sp(c).edit().putFloat("thr", t).apply()

    // ---- Alerts: parent phone number + in-app log ----
    fun phone(c: Context) = sp(c).getString("phone", "") ?: ""
    fun setPhone(c: Context, p: String) = sp(c).edit().putString("phone", p.trim()).apply()
    fun lastSms(c: Context) = sp(c).getLong("lastSms", 0)
    fun markSms(c: Context) = sp(c).edit().putLong("lastSms", System.currentTimeMillis()).apply()

    fun log(c: Context, line: String) {
        val stamp = java.time.LocalDateTime.now().toString().take(16).replace('T', ' ')
        val old = (sp(c).getString("log", "") ?: "").lines().filter { it.isNotBlank() }
        sp(c).edit().putString("log", (listOf("$stamp  $line") + old).take(50).joinToString("\n")).apply()
    }
    fun logText(c: Context) = (sp(c).getString("log", "") ?: "").ifBlank { "(no alerts yet)" }
    fun clearLog(c: Context) = sp(c).edit().putString("log", "").apply()
}
