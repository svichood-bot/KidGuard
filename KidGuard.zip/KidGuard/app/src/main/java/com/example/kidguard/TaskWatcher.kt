package com.example.kidguard

import android.app.Service
import android.content.Intent
import android.os.IBinder

/**
 * Started whenever the KidGuard screen opens. Android calls onTaskRemoved only when the app is swiped away
 * from the recent-apps list (not when you just press Home), so that is when parent mode ends.
 */
class TaskWatcher : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (Store.parentActive(this)) {
            Store.endParent(this)
            Store.setAllowInstalls(this, false)
            Hardening.apply(this)
            Store.log(this, "Parent mode ended (app was closed).")
        }
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }
}
