package com.example.kidguard

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

/** Device admin: makes Android refuse to uninstall KidGuard until admin is deactivated. */
class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        Alerts.send(context, "KidGuard tamper attempt", "Someone tried to deactivate KidGuard admin.")
        return "Disabling KidGuard will notify your parent."
    }
    override fun onDisabled(context: Context, intent: Intent) {
        Alerts.send(context, "KidGuard disabled", "Device admin was turned off.")
    }
}
