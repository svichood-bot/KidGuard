package com.example.kidguard

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.os.UserManager

/**
 * Only works when KidGuard is the Device Owner (one-time adb step, see README).
 * Blocks safe mode, factory reset, new users, sideloading, and force-stop/clear-data of apps.
 */
object Hardening {
    private val RESTRICTIONS = listOf(
        UserManager.DISALLOW_SAFE_BOOT,
        UserManager.DISALLOW_FACTORY_RESET,
        UserManager.DISALLOW_ADD_USER,
        UserManager.DISALLOW_INSTALL_UNKNOWN_SOURCES,
        UserManager.DISALLOW_APPS_CONTROL
    )
    // Blocked too, unless the parent said yes to an uninstall request (short window).
    private const val NO_UNINSTALL = UserManager.DISALLOW_UNINSTALL_APPS
    // Blocked too, unless the parent has switched installs on for this parent session.
    private const val NO_INSTALL = UserManager.DISALLOW_INSTALL_APPS

    private fun dpm(c: Context) = c.getSystemService(DevicePolicyManager::class.java)
    private fun admin(c: Context) = ComponentName(c, AdminReceiver::class.java)

    fun isOwner(c: Context) = dpm(c).isDeviceOwnerApp(c.packageName)

    fun apply(c: Context) {
        if (!isOwner(c)) return
        try {
            RESTRICTIONS.forEach { dpm(c).addUserRestriction(admin(c), it) }
            if (Store.allowInstalls(c) || Store.installWindowOpen(c)) dpm(c).clearUserRestriction(admin(c), NO_INSTALL)
            else dpm(c).addUserRestriction(admin(c), NO_INSTALL)
            if (Store.uninstallWindowOpen(c)) dpm(c).clearUserRestriction(admin(c), NO_UNINSTALL)
            else dpm(c).addUserRestriction(admin(c), NO_UNINSTALL)
            dpm(c).setUninstallBlocked(admin(c), c.packageName, true)
        } catch (e: Exception) { }
    }

    /** Parent-only: undo everything so the phone is normal again. */
    fun release(c: Context) {
        if (!isOwner(c)) return
        try {
            RESTRICTIONS.forEach { dpm(c).clearUserRestriction(admin(c), it) }
            dpm(c).clearUserRestriction(admin(c), NO_INSTALL)
            dpm(c).clearUserRestriction(admin(c), NO_UNINSTALL)
            dpm(c).setUninstallBlocked(admin(c), c.packageName, false)
            dpm(c).clearDeviceOwnerApp(c.packageName)
        } catch (e: Exception) { }
    }
}
