package com.example.kidguard

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

/**
 * On-device image classifier. Fully offline.
 * Put a TFLite model at app/src/main/assets/nsfw.tflite
 * Expected: input float32 [1,224,224,3], output [1,2] = [safe, nsfw].
 * YAHOO_STYLE = true  -> for the Yahoo open_nsfw model (BGR, 0..255, minus mean 104/117/123).
 * YAHOO_STYLE = false -> for models that want plain RGB scaled 0..1.
 * If the file is missing the scanner is simply disabled.
 */
private const val YAHOO_STYLE = true

class NsfwScanner(ctx: Context) {
    private val interp: Interpreter? = try {
        val fd = ctx.assets.openFd("nsfw.tflite")
        val buf = FileInputStream(fd.fileDescriptor).channel
            .map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
        Interpreter(buf)
    } catch (e: Exception) { null }

    /** A model file exists in assets (even if it turns out to be the wrong kind). */
    val present get() = interp != null

    /** Only float32-input models are supported; anything else keeps the filter off instead of crashing. */
    val ready: Boolean get() = try {
        interp?.getInputTensor(0)?.dataType() == org.tensorflow.lite.DataType.FLOAT32
    } catch (e: Exception) { false }

    @Volatile var broken = false

    fun score(src: Bitmap): Float {
        val ip = interp ?: return 0f
        return try {
            val b = Bitmap.createScaledBitmap(src, 224, 224, true)
            val px = IntArray(224 * 224)
            b.getPixels(px, 0, 224, 0, 0, 224, 224)
            val buf = ByteBuffer.allocateDirect(4 * 224 * 224 * 3).order(ByteOrder.nativeOrder())
            for (p in px) {
                val r = ((p shr 16) and 0xFF).toFloat()
                val g = ((p shr 8) and 0xFF).toFloat()
                val bl = (p and 0xFF).toFloat()
                if (YAHOO_STYLE) {
                    buf.putFloat(bl - 104f); buf.putFloat(g - 117f); buf.putFloat(r - 123f)
                } else {
                    buf.putFloat(r / 255f); buf.putFloat(g / 255f); buf.putFloat(bl / 255f)
                }
            }
            val out = Array(1) { FloatArray(2) }
            ip.run(buf, out)
            out[0][1]
        } catch (e: Exception) {
            broken = true // wrong model shape/type: never crash the protection service over it
            0f
        }
    }
}
