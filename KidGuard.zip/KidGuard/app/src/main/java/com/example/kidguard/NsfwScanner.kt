package com.example.kidguard

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

/**
 * On-device image classifier. Fully offline.
 * Put a TFLite model at app/src/main/assets/nsfw.tflite
 * Expected: input float32 [1,224,224,3] scaled 0..1, output [1,2] = [safe, nsfw].
 * If the file is missing the scanner is simply disabled.
 */
class NsfwScanner(ctx: Context) {
    private val interp: Interpreter? = try {
        val fd = ctx.assets.openFd("nsfw.tflite")
        val buf = FileInputStream(fd.fileDescriptor).channel
            .map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
        Interpreter(buf)
    } catch (e: Exception) { null }

    val ready get() = interp != null

    fun score(src: Bitmap): Float {
        val ip = interp ?: return 0f
        val b = Bitmap.createScaledBitmap(src, 224, 224, true)
        val px = IntArray(224 * 224)
        b.getPixels(px, 0, 224, 0, 0, 224, 224)
        val buf = ByteBuffer.allocateDirect(4 * 224 * 224 * 3).order(ByteOrder.nativeOrder())
        for (p in px) {
            buf.putFloat(((p shr 16) and 0xFF) / 255f)
            buf.putFloat(((p shr 8) and 0xFF) / 255f)
            buf.putFloat((p and 0xFF) / 255f)
        }
        val out = Array(1) { FloatArray(2) }
        ip.run(buf, out)
        return out[0][1]
    }
}
