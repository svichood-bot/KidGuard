package com.example.kidguard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

/** After every reboot: re-apply hardening and tell the parent whether protection survived. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED) return
        Hardening.apply(c)
        val on = (Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
            .contains(c.packageName)
        Alerts.send(c, "Phone restarted", if (on) "Protection is ON." else "WARNING: protection is OFF after restart.")
    }
}
