package com.example.kidguard

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SmsManager

/** Every alert is saved to the in-app log, and texted to the parent if a number is set. SMS needs no internet. */
object Alerts {
    fun send(c: Context, title: String, msg: String): Boolean {
        Store.log(c, "$title - $msg")
        val num = Store.phone(c)
        if (num.isBlank()) return false
        if (c.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return false
        if (System.currentTimeMillis() - Store.lastSms(c) < 30_000) return false // avoid text spam
        val name = Store.childName(c)
        val who = if (name.isBlank()) "KidGuard" else "KidGuard - $name's phone"
        try {
            val sms = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java)
                      else @Suppress("DEPRECATION") SmsManager.getDefault()
            val parts = sms.divideMessage("$who: $title - $msg")
            sms.sendMultipartTextMessage(num, null, parts, null, null)
            Store.markSms(c)
            return true
        } catch (e: Exception) { /* logged in-app regardless */ }
        return false
    }
}
