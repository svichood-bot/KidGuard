package com.example.kidguard

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SmsManager

/** Every alert is saved to the in-app log, and texted to the parent if a number is set. SMS needs no internet. */
object Alerts {
    fun send(c: Context, title: String, msg: String) {
        Store.log(c, "$title - $msg")
        val num = Store.phone(c)
        if (num.isBlank()) return
        if (c.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return
        if (System.currentTimeMillis() - Store.lastSms(c) < 30_000) return // avoid text spam
        try {
            val sms = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java)
                      else @Suppress("DEPRECATION") SmsManager.getDefault()
            val parts = sms.divideMessage("KidGuard: $title - $msg")
            sms.sendMultipartTextMessage(num, null, parts, null, null)
            Store.markSms(c)
        } catch (e: Exception) { /* logged in-app regardless */ }
    }
}
