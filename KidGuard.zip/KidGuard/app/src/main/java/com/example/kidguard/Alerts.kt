package com.example.kidguard

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SmsManager

/**
 * Every alert is saved to the in-app log (parent mode > Recent alerts).
 * It is only TEXTED when sms = true. Only two things ever pass sms = true:
 * the kid's single "more time" request, and the nudity filter (plus the manual test button).
 */
object Alerts {
    fun send(c: Context, title: String, msg: String, sms: Boolean = false): Boolean {
        Store.log(c, "$title - $msg")
        if (!sms) return false
        val num = Store.phone(c)
        if (num.isBlank()) return false
        if (c.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return false
        if (System.currentTimeMillis() - Store.lastSms(c) < 10_000) return false // double-tap guard only
        val name = Store.childName(c)
        val who = if (name.isBlank()) "KidGuard" else "KidGuard - $name's phone"
        try {
            val sm = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java)
                     else @Suppress("DEPRECATION") SmsManager.getDefault()
            val parts = sm.divideMessage("$who: $title - $msg")
            sm.sendMultipartTextMessage(num, null, parts, null, null)
            Store.markSms(c)
            return true
        } catch (e: Exception) { /* logged in-app regardless */ }
        return false
    }
}
