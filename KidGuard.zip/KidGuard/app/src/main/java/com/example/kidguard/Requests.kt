package com.example.kidguard

import android.app.PendingIntent
import android.content.Context
import android.content.Intent

/** Carries out the parent's answer to the kid's "install" / "uninstall" request (by text or in parent mode). */
object Requests {
    const val INSTALL_MIN = 30
    const val UNINSTALL_MIN = 15

    fun approve(c: Context, r: Store.Req): String {
        Store.removeRequest(c, r.id)
        return if (r.type == "install") {
            Store.addApprovedName(c, r.name)
            Store.openInstallWindow(c, INSTALL_MIN)
            Hardening.apply(c)
            Store.log(c, "Parent allowed installing \"${r.name}\" (installs open for $INSTALL_MIN min).")
            "Allowed: \"${r.name}\" can be installed for the next $INSTALL_MIN min, then installs lock again."
        } else {
            Store.openUninstallWindow(c, UNINSTALL_MIN)
            Hardening.apply(c)
            val done = tryUninstall(c, r.pkg)
            Store.log(c, "Parent allowed removing \"${r.name}\" (uninstall open for $UNINSTALL_MIN min).")
            if (done) "Allowed: removing \"${r.name}\" now."
            else "Allowed: \"${r.name}\" can be uninstalled for the next $UNINSTALL_MIN min."
        }
    }

    fun decline(c: Context, r: Store.Req): String {
        Store.removeRequest(c, r.id)
        Store.log(c, "Parent said no to ${r.type} of \"${r.name}\".")
        return "Declined: \"${r.name}\"."
    }

    /** Silent when KidGuard is Device Owner. Otherwise nothing happens here and the kid removes it themselves in the window. */
    private fun tryUninstall(c: Context, pkg: String): Boolean {
        if (pkg.isBlank() || pkg == c.packageName || !Hardening.isOwner(c)) return false
        return try {
            val done = PendingIntent.getBroadcast(
                c, 0, Intent("com.example.kidguard.UNINSTALL_DONE").setPackage(c.packageName),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            ).intentSender
            c.packageManager.packageInstaller.uninstall(pkg, done)
            true
        } catch (e: Exception) { false }
    }
}
