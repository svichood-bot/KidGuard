package com.example.kidguard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View

/** "KidGuard" in a chunky, rounded, slightly bouncy style. Drawn in code, so no font file is needed. */
class Wordmark(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val word = "KidGuard"
    private val kidColor = Color.parseColor("#00BF93")
    private val guardColor = Color.parseColor("#04665B")
    private val shadowColor = Color.parseColor("#CDF3EC")
    private val bounce = floatArrayOf(0f, -3f, 2f, -2f, 3f, -2f, 2f, -3f)
    private val tilt = floatArrayOf(-4f, 3f, -2f, 4f, -3f, 2f, -4f, 3f)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        textSize = 46f * d
        style = Paint.Style.FILL_AND_STROKE   // the outline rounds every corner = friendly, chunky letters
        strokeWidth = 3f * d
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }
    private val advances: List<Float> = word.map { paint.measureText(it.toString()) + 1.5f * d }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val fm = paint.fontMetrics
        setMeasuredDimension((advances.sum() + 16f * d).toInt(), (fm.descent - fm.ascent + 20f * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val fm = paint.fontMetrics
        val base = 10f * d - fm.ascent
        var x = 8f * d
        word.forEachIndexed { i, ch ->
            val s = ch.toString()
            val adv = advances[i]
            c.save()
            c.rotate(tilt[i], x + adv / 2, base - paint.textSize / 3)
            c.translate(0f, bounce[i] * d)
            paint.color = shadowColor                      // soft sticker shadow
            c.drawText(s, x + 1.5f * d, base + 4f * d, paint)
            paint.color = if (i < 3) kidColor else guardColor
            c.drawText(s, x, base, paint)
            c.restore()
            x += adv
        }
    }
}
