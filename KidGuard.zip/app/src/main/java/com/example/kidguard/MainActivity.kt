package com.example.kidguard

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private val teal = Color.parseColor("#03D8C0")
    private val dark = Color.parseColor("#04665B")
    private val soft = Color.parseColor("#E9FBF8")
    private val reqExport = 10
    private val reqImport = 11
    // Sub-screens stack ("help", "apps", "request"). Back pops one; empty = the main screen.
    private val stack = ArrayList<String>()
    private val ui = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            // Keeps the kid's time-left fresh (e.g. after a parent texts "OK 30"). Never on screens with typing.
            if (stack.isEmpty() && Store.hasPin(this@MainActivity) && !Store.parentActive(this@MainActivity)) render()
            else if (stack.lastOrNull() == "request") render()
            ui.postDelayed(this, 8000)
        }
    }

    companion object {
        /** True while a KidGuard screen is in front. The service uses it so popups never kick the app away. */
        @Volatile var visible = false
    }

    private fun push(name: String) { stack.add(name); render() }
    private fun pop() { if (stack.isNotEmpty()) stack.removeAt(stack.size - 1); render() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = teal
    }

    override fun onResume() {
        super.onResume()
        visible = true
        render()
        ui.removeCallbacks(refresh)
        ui.postDelayed(refresh, 8000)
    }

    override fun onPause() {
        visible = false
        ui.removeCallbacks(refresh)
        super.onPause()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (stack.isNotEmpty()) pop()
        else moveTaskToBack(true) // back from the main screen = phone's home screen, app stays alive
    }

    private fun render() {
        if (stack.lastOrNull() == "apps" && !Store.parentActive(this)) stack.clear() // parent mode ended
        when (stack.lastOrNull()) {
            "help" -> helpScreen()
            "apps" -> appsScreen()
            "request" -> requestScreen()
            else -> when {
                !Store.hasPin(this) -> setupScreen()
                Store.parentActive(this) -> { Hardening.apply(this); parentScreen() }
                else -> kidScreen()
            }
        }
    }

    // ---------- look & feel helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(fill: Int, radiusDp: Int, strokeColor: Int? = null) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radiusDp).toFloat()
        if (strokeColor != null) setStroke(dp(2), strokeColor)
    }

    private fun margins(top: Int = 0, bottom: Int = 10) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(0, dp(top), 0, dp(bottom)) }

    private fun show(vararg views: View) {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(24))
        }
        views.forEach { col.addView(it) }
        setContentView(ScrollView(this).apply { setBackgroundColor(soft); addView(col) })
    }

    private fun tv(t: String, sz: Float = 16f, bold: Boolean = false, center: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = sz; setTextColor(dark)
            setPadding(0, dp(4), 0, dp(4))
            if (bold) setTypeface(typeface, Typeface.BOLD)
            if (center) gravity = Gravity.CENTER
        }

    private fun btn(t: String, primary: Boolean = true, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 16f
        setTypeface(typeface, Typeface.BOLD)
        stateListAnimator = null
        if (primary) { setTextColor(Color.WHITE); background = shape(dark, 26) }
        else { setTextColor(dark); background = shape(Color.WHITE, 26, teal) }
        setPadding(dp(16), dp(12), dp(16), dp(12))
        layoutParams = margins(4, 8)
        setOnClickListener { f() }
    }

    private fun edit(hint: String, text: String, type: Int, lines: Int = 1) = EditText(this).apply {
        this.hint = hint; setText(text); inputType = type
        setTextColor(Color.BLACK)
        background = shape(Color.WHITE, 14, teal)
        setPadding(dp(14), dp(10), dp(14), dp(10))
        if (lines > 1) { minLines = lines; gravity = Gravity.TOP }
        layoutParams = margins(2, 8)
    }

    private fun card(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(Color.WHITE, 22, teal)
        setPadding(dp(16), dp(12), dp(16), dp(12))
        layoutParams = margins(0, 14)
        views.forEach { addView(it) }
    }

    private fun logo() = ImageView(this).apply {
        setImageResource(R.drawable.kg_logo)
        adjustViewBounds = true
        layoutParams = LinearLayout.LayoutParams(dp(190), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            setMargins(0, 0, 0, dp(8))
        }
    }

    private fun pinDialog(title: String, ok: (String) -> Unit) {
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ -> ok(et.text.toString()) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun backBtn() = btn("← Back", false) { pop() }
    private fun homeBtn() = btn("🏠 Home screen", false) { moveTaskToBack(true) }

    // ---------- status checks ----------
    private fun a11yOn() = (Settings.Secure.getString(
        contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)

    private fun adminComp() = ComponentName(this, AdminReceiver::class.java)

    private fun adminOn() =
        (getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager).isAdminActive(adminComp())

    private fun smsOn() =
        checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED &&
        checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED

    /** Android 13+ blocks Accessibility/SMS for apps installed from a file until "Allow restricted settings". */
    private fun restrictedBlocked(): Boolean {
        if (Build.VERSION.SDK_INT < 33) return false
        return try {
            val mode = getSystemService(AppOpsManager::class.java)
                .unsafeCheckOpNoThrow("android:access_restricted_settings", Process.myUid(), packageName)
            mode == AppOpsManager.MODE_ERRORED || mode == AppOpsManager.MODE_IGNORED
        } catch (e: Exception) { false }
    }

    // ---------- copy settings between phones ----------
    private fun pickImport() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), reqImport)
    }

    private fun startExport() {
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE).setType("application/json")
            .putExtra(Intent.EXTRA_TITLE, "kidguard-settings.json"), reqExport)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            if (requestCode == reqExport) {
                contentResolver.openOutputStream(uri)?.use { it.write(Store.exportJson(this).toByteArray()) }
                toast("Settings file saved ✅")
            } else if (requestCode == reqImport) {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                toast(if (Store.importJson(this, text)) "Settings loaded ✅" else "That isn't a KidGuard settings file")
            }
        } catch (e: Exception) { toast("Couldn't use that file") }
    }

    // ---------- screens ----------
    private fun setupScreen() {
        val name = edit("e.g. Mia", "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS)
        val p1 = edit("Choose a PIN (4-8 digits)", "",
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        val p2 = edit("Confirm PIN", "",
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        val phone = edit("Your mobile number", Store.phone(this), InputType.TYPE_CLASS_PHONE)
        show(
            logo(),
            tv("Welcome to KidGuard 👋", 26f, true, true),
            tv("Let's set up this phone in a few quick steps.", 15f, false, true),
            card(
                tv("1. Whose phone is this?", 18f, true), name,
                tv("Your texts will say \"KidGuard - Mia's phone\" so you know which child it is.", 13f)
            ),
            card(tv("2. Parent PIN", 18f, true), p1, p2,
                tv("Keep it secret and different from the phone's screen lock.", 13f)),
            card(tv("3. Where should alerts be texted?", 18f, true), phone,
                tv("Texts go straight from this phone. No other app needed.", 13f)),
            btn("Start setup ➜") {
                val a = p1.text.toString()
                when {
                    name.text.toString().isBlank() -> toast("Please type the child's name")
                    a.length !in 4..8 || a != p2.text.toString() -> toast("PINs must match (4-8 digits)")
                    else -> {
                        Store.setChildName(this, name.text.toString())
                        Store.setPhone(this, phone.text.toString())
                        Store.setPin(this, a)
                        Store.startParent(this)
                        render()
                    }
                }
            },
            btn("Copy settings from another phone", false) { pickImport() },
            btn("Help & tips", false) { push("help") },
            homeBtn()
        )
    }

    private fun kidScreen() {
        val name = Store.childName(this)
        val left = Store.timeLeftMin(this).toInt()
        val limit = maxOf(Store.totalMin(this), 1)
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = limit
            progress = left.coerceIn(0, limit)
            progressTintList = ColorStateList.valueOf(teal)
            layoutParams = margins(8, 8)
        }
        show(
            logo(),
            tv(if (name.isBlank()) "Hi there! 😊" else "Hi $name! 😊", 32f, true, true),
            card(
                tv("⏰ Time left today", 16f, false, true),
                tv(if (left > 0) "$left min" else "All done for today! 🌙", 30f, true, true),
                bar
            ),
            card(tv("🌐 Only approved websites work", 16f, false, true)),
            btn("⏰ Ask for more time", true) {
                if (Store.requestPending(this)) {
                    toast("Already asked. Please wait for a reply 😊")
                } else {
                    val name2 = Store.childName(this).ifBlank { "Your child" }
                    val sent = Alerts.send(this, "More time please",
                        "$name2 asked for more time (${Store.timeLeftMin(this)} min left today). " +
                        "Reply \"OK 30\" to add 30 min today (or \"OK\" for 15). No reply = no.", sms = true)
                    if (sent) Store.markRequest(this) // one request, one text: no more until answered or 30 min pass
                    toast(if (sent) "Asked! 📨 Waiting for a reply" else "Couldn't send the text. Ask a parent here 🙂")
                }
                push("request")
            },
            btn("🔑 Parent: give more time here", false) { push("request") },
            btn("Parent login 🔒", false) {
                pinDialog("Parent PIN") {
                    if (Store.checkPin(this, it)) { Store.startParent(this); render() }
                    else toast("Wrong PIN")
                }
            },
            homeBtn()
        )
    }

    /** Request sent + parent can approve right on this phone with their PIN (works with no texting at all). */
    private fun requestScreen() {
        val left = Store.timeLeftMin(this)
        fun grant(m: Int) = pinDialog("Parent PIN to add $m min") {
            if (Store.checkPin(this, it)) {
                Store.addBonus(this, m)
                Store.log(this, "Parent added +$m min on the phone. ${Store.timeLeftMin(this)} min left.")
                toast("Added $m min ✅"); stack.clear(); render()
            } else toast("Wrong PIN")
        }
        show(
            logo(),
            tv("More time ⏰", 26f, true, true),
            card(
                tv(if (Store.requestPending(this)) "📨 Your request was sent. A parent can reply by text, or approve right here."
                   else "A parent can give you more time right here.", 15f, false, true),
                tv("Time left today: $left min", 16f, true, true)
            ),
            card(
                tv("👨‍👩‍👧 Parent: add time now (needs your PIN)", 16f, true),
                btn("+15 min") { grant(15) },
                btn("+30 min") { grant(30) },
                btn("+60 min") { grant(60) }
            ),
            backBtn(),
            homeBtn()
        )
    }

    private fun stepRow(
        done: Boolean, title: String, hint: String? = null,
        actionLabel: String? = null, action: (() -> Unit)? = null
    ): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        col.addView(tv((if (done) "✅  " else "⬜  ") + title, 16f, true))
        if (!done) {
            if (hint != null) col.addView(tv(hint, 13f))
            if (actionLabel != null && action != null) col.addView(btn(actionLabel, true, action))
        }
        return col
    }

    private fun parentScreen() {
        val name = Store.childName(this)
        val who = if (name.isBlank()) "this phone" else "$name's phone"

        val nameBox = edit("Child's name", name, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS)
        val limit = edit("Daily limit (minutes)", Store.limitMin(this).toString(), InputType.TYPE_CLASS_NUMBER)
        val allow = edit("One website per line, e.g. wikipedia.org", Store.allowText(this),
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE, 6)
        val sens = edit("Nudity filter sensitivity %", (Store.threshold(this) * 100).toInt().toString(),
            InputType.TYPE_CLASS_NUMBER)
        val phone = edit("Your mobile number for text alerts", Store.phone(this), InputType.TYPE_CLASS_PHONE)

        fun save() {
            Store.setChildName(this, nameBox.text.toString())
            Store.setLimitMin(this, limit.text.toString().toIntOrNull() ?: 60)
            Store.setAllowText(this, allow.text.toString())
            Store.setThreshold(this, ((sens.text.toString().toIntOrNull() ?: 70).coerceIn(10, 99)) / 100f)
            Store.setPhone(this, phone.text.toString())
        }

        // ----- setup checklist -----
        val steps = mutableListOf<Pair<Boolean, View>>()
        fun step(done: Boolean, title: String, hint: String? = null, label: String? = null, act: (() -> Unit)? = null) {
            steps.add(done to stepRow(done, title, hint, label, act))
        }
        if (restrictedBlocked()) {
            step(false, "Allow restricted settings",
                "Android blocks apps installed from a file. Tap below, then the ⋮ menu (top right) → \"Allow restricted settings\", then come back.",
                "Open KidGuard app info") {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:$packageName")))
            }
        }
        step(smsOn(), "Allow texting", "Lets KidGuard text you (time requests and nudity only), and lets you text back \"OK 30\" to give more time.", "Allow texting") {
            requestPermissions(arrayOf(Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS), 1)
        }
        step(Store.phone(this).isNotBlank(), "Your mobile number is saved",
            "Type it in the box below, then tap Save settings.")
        step(adminOn(), "Uninstall protection", "Stops the app being removed.", "Turn on") {
            startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComp()))
        }
        step(a11yOn(), "Protection service", "Find KidGuard in the list and switch it on.", "Open Accessibility settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        val hasModel = try { assets.list("")?.contains("nsfw.tflite") == true } catch (e: Exception) { false }
        step(hasModel, "Nudity filter model",
            "No picture-checking file (nsfw.tflite) is inside this app, so NO pictures are scanned and no nudity texts can be sent. Add it to app/src/main/assets (see README), rebuild and reinstall.")
        if (android.os.Build.VERSION.SDK_INT < 30)
            step(false, "Picture scanning needs Android 11+",
                "This phone runs Android ${android.os.Build.VERSION.RELEASE}. Older Android can't let KidGuard look at the screen, so the nudity filter can't work on this phone.")
        val doneCount = steps.count { it.first }
        val allDone = doneCount == steps.size

        val checklist = card(
            tv(if (allDone) "🎉 All set! KidGuard is protecting $who." else "🚀 Setup: $doneCount of ${steps.size} done", 18f, true),
            *steps.map { it.second }.toTypedArray(),
            tv(if (Hardening.isOwner(this)) "✅  Safe-mode & factory-reset lock is ON"
               else "➕  Optional: lock safe mode & factory reset (needs a computer, see Help)", 14f)
        )

        // ----- new apps waiting for approval -----
        val pm = packageManager
        val pending = try { pm.getInstalledApplications(0).filter { isNewApp(it) } }
            catch (e: Exception) { emptyList<ApplicationInfo>() }
        val approveViews = ArrayList<View>()
        approveViews.add(tv("🆕 New apps waiting for approval", 18f, true))
        approveViews.add(tv("Apps installed after setup can't be opened until you approve them.", 13f))
        if (pending.isEmpty()) approveViews.add(tv("None right now 👍", 14f))
        pending.forEach { ai ->
            approveViews.add(tv(ai.loadLabel(pm).toString(), 16f, true))
            approveViews.add(btn("Approve") { Store.approve(this, ai.packageName); render() })
        }

        // ----- installs / uninstalls -----
        val owner = Hardening.isOwner(this)
        val installViews = ArrayList<View>()
        installViews.add(tv("📦 Installing & uninstalling apps", 18f, true))
        if (owner) {
            val allowed = Store.allowInstalls(this)
            installViews.add(tv(if (allowed) "🔓 Installs are allowed until you leave parent mode (then they lock again)."
                else "🔒 Nobody can install or uninstall apps on this phone.", 14f))
            installViews.add(btn(if (allowed) "Block installs again" else "Allow installs for now", false) {
                Store.setAllowInstalls(this, !allowed); Hardening.apply(this); render()
            })
        } else {
            installViews.add(tv("To block ALL installs and uninstalls you need the Device Owner step (see Help). " +
                "Without it, new apps are still locked until you approve them below.", 13f))
        }

        show(
            homeBtn(),
            logo(),
            tv("Parent mode", 26f, true, true),
            tv("Setting up $who. Locks itself after 10 minutes.", 13f, false, true),
            *listOfNotNull(flagsCard()).toTypedArray(),
            checklist,
            card(*installViews.toTypedArray()),
            card(*approveViews.toTypedArray()),
            card(
                tv("📱 Apps", 18f, true),
                tv("Everything is blocked except phone and messages. Allow the apps you want here (there is a search box to find one fast).", 13f),
                btn("Choose apps") { save(); push("apps") }
            ),
            card(
                tv("👧 Child & limits", 18f, true),
                tv("Child's name", 13f), nameBox,
                tv("Daily screen time (minutes)", 13f), limit,
                tv("Allowed websites (everything else is blocked)", 13f), allow,
                tv("Nudity filter (lower % = stricter)", 13f), sens,
                tv("Your mobile number for text alerts", 13f), phone,
                btn("Save settings 💾") { save(); toast("Saved"); render() }
            ),
            card(
                tv("📲 Copy settings to another phone", 18f, true),
                tv("Save your settings to a file, then load it on each child's phone (send it by email, Drive or Bluetooth). " +
                   "Your app choices, time limit, websites, filter, child's name and number are all saved, so you can also use this after reinstalling KidGuard (save it BEFORE you uninstall, and keep it in Downloads). The PIN is not saved.", 13f),
                btn("Save settings to a file") { save(); startExport() },
                btn("Load settings from a file", false) { pickImport() }
            ),
            card(
                tv("⏰ Give extra time today", 18f, true),
                tv("Left today: ${Store.timeLeftMin(this)} min", 14f),
                btn("+15 min", false) { Store.addBonus(this, 15); toast("+15 min"); render() },
                btn("+30 min", false) { Store.addBonus(this, 30); toast("+30 min"); render() },
                btn("+60 min", false) { Store.addBonus(this, 60); toast("+60 min"); render() }
            ),
            card(
                tv("🔔 Alerts", 18f, true),
                tv("Texts are sent only for a time request and for the nudity filter. Everything else is just listed below.", 13f),
                btn("Send test alert") { save(); Alerts.send(this, "KidGuard test", "Alerts are working.", sms = true); toast("Sent"); render() },
                tv(Store.logText(this), 13f),
                btn("Clear alert log", false) { Store.clearLog(this); render() }
            ),
            card(
                tv("🛠 More", 18f, true),
                btn("Reset today's timer", false) {
                    getSharedPreferences("kg", MODE_PRIVATE).edit().putLong("used", 0).apply(); toast("Reset"); render()
                },
                btn("Remove ALL protection (release Device Owner)", false) {
                    AlertDialog.Builder(this).setTitle("Remove protection?")
                        .setMessage("Safe mode, factory reset and uninstall will no longer be blocked.")
                        .setPositiveButton("Remove") { _, _ -> Hardening.release(this); render() }
                        .setNegativeButton("Cancel", null).show()
                },
                btn("🗑 Uninstall KidGuard", false) {
                    AlertDialog.Builder(this).setTitle("Uninstall KidGuard?")
                        .setMessage("This switches off all protection on this phone and opens Android's uninstall screen. " +
                            "If you cancel that screen, turn \"Uninstall protection\" back on in the setup checklist.")
                        .setPositiveButton("Uninstall") { _, _ -> uninstallSelf() }
                        .setNegativeButton("Cancel", null).show()
                },
                btn("Help & tips", false) { push("help") }
            ),
            btn("Exit parent mode 🔒") {
                save(); Store.setAllowInstalls(this, false); Hardening.apply(this); Store.endParent(this); render()
            }
        )
    }

    /** Parent mode only: drop Device Owner + device admin (they block uninstall), then open Android's uninstall prompt. */
    private fun uninstallSelf() {
        try { if (Hardening.isOwner(this)) Hardening.release(this) } catch (e: Exception) {}
        try {
            (getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager).removeActiveAdmin(adminComp())
        } catch (e: Exception) {}
        Store.setAllowInstalls(this, false)
        try {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            toast("Couldn't open the uninstall screen. Try Settings > Apps > KidGuard > Uninstall")
        }
    }

    private fun isNewApp(ai: ApplicationInfo): Boolean {
        val system = (ai.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0
        if (system || ai.packageName == packageName || ai.packageName in Store.approvedApps(this) ||
            ai.packageName in Store.essential(this)) return false
        return try {
            packageManager.getPackageInfo(ai.packageName, 0).firstInstallTime > Store.baseline(this)
        } catch (e: Exception) { false }
    }

    // ---------- flagged pictures (parent mode) ----------
    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    private fun flagsCard(): View? {
        val items = FlagStore.list(this)
        if (items.isEmpty()) return null
        val views = ArrayList<View>()
        views.add(tv("🚩 Flagged pictures (${items.size})", 18f, true))
        views.add(tv("Saved only inside KidGuard (not in the gallery) and deleted after 7 days. " +
            "Tap View to see the real picture, or Open app to go and remove it there.", 13f))
        items.take(20).forEach { views.add(flagRow(it)) }
        views.add(btn("Delete all flagged pictures", false) { FlagStore.clear(this); render() })
        return card(*views.toTypedArray())
    }

    private fun flagRow(f: FlagStore.Item): View {
        val app = appLabel(f.pkg)
        val whenText = java.text.SimpleDateFormat("EEE d MMM, h:mm a", java.util.Locale.getDefault())
            .format(java.util.Date(f.time))
        val thumb = ImageView(this).apply {
            FlagStore.pixelated(f.file)?.let { setImageBitmap(it) }
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = LinearLayout.LayoutParams(dp(72), dp(72)).apply { setMargins(0, 0, dp(12), 0) }
        }
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv(app, 16f, true))
            addView(tv("$whenText • ${f.percent}% match", 13f))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(thumb); addView(info)
        }
        fun small(t: String, primary: Boolean, action: () -> Unit): Button = btn(t, primary, action).apply {
            textSize = 13f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                .apply { setMargins(dp(2), dp(4), dp(2), 0) }
        }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(small("View", true) { viewFlag(f, app, whenText) })
            addView(small("Open app", false) {
                val i = packageManager.getLaunchIntentForPackage(f.pkg)
                if (i != null) startActivity(i) else toast("Can't open that app")
            })
            addView(small("Delete", false) { FlagStore.delete(f.file); render() })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(8))
            addView(top); addView(buttons)
        }
    }

    private fun viewFlag(f: FlagStore.Item, app: String, whenText: String) {
        val img = ImageView(this).apply {
            adjustViewBounds = true
            setPadding(dp(8), dp(8), dp(8), dp(8))
            FlagStore.full(f.file)?.let { setImageBitmap(it) }
        }
        AlertDialog.Builder(this)
            .setTitle("$app • $whenText")
            .setView(ScrollView(this).apply { addView(img) })
            .setPositiveButton("Close", null)
            .setNeutralButton("Delete") { _, _ -> FlagStore.delete(f.file); render() }
            .show()
    }

    private fun appRow(pkg: String, label: String): View {
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("Normal (counts toward limit)", "No time limit", "Blocked"))
        spinner.setSelection(Store.appRule(this, pkg))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos != Store.appRule(this@MainActivity, pkg)) Store.setAppRule(this@MainActivity, pkg, pos)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        return card(tv(if (pkg in Store.essential(this)) "$label 📞" else label, 16f, true), spinner)
    }

    private fun appsScreen() {
        val pm = packageManager
        val seen = HashSet<String>()
        val rows = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).mapNotNull { ri ->
            val pkg = ri.activityInfo.packageName
            if (pkg == packageName || !seen.add(pkg)) null else Pair(pkg, ri.loadLabel(pm).toString())
        }.sortedBy { it.second.lowercase() }
        val views = ArrayList<View>()
        views.add(backBtn())
        views.add(tv("Apps", 26f, true))
        views.add(tv("Every app is Blocked unless you allow it here. Choose Normal (counts toward the daily limit) or " +
            "No time limit for the ones you want. Phone and messaging apps 📞 are always allowed with no time limit.", 14f))
        val search = edit("🔍 Search apps", "", InputType.TYPE_CLASS_TEXT).apply { isSingleLine = true }
        views.add(search)
        val rowViews = rows.map { Triple(it.first, it.second, appRow(it.first, it.second)) }
        val none = tv("No apps match that search.", 14f).apply { visibility = View.GONE }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString()?.trim().orEmpty()
                var shown = 0
                rowViews.forEach { (pkg, label, v) ->
                    val ok = q.isEmpty() || label.contains(q, ignoreCase = true) || pkg.contains(q, ignoreCase = true)
                    v.visibility = if (ok) View.VISIBLE else View.GONE
                    if (ok) shown++
                }
                none.visibility = if (shown == 0) View.VISIBLE else View.GONE
            }
        })
        views.add(none)
        rowViews.forEach { views.add(it.third) }
        views.add(btn("Done") { pop() })
        views.add(backBtn())
        show(*views.toTypedArray())
    }

    private fun helpScreen() {
        fun h(t: String) = tv(t, 18f, true)
        fun p(t: String) = tv(t, 14f)
        show(
            backBtn(),
            tv("Help & tips", 26f, true),
            card(h("What KidGuard does"),
                p("• Daily screen-time limit\n• Only websites you approve will open (Chrome and other browsers)\n" +
                  "• Scans the screen for nudity on the phone itself (needs a model file, see README)\n" +
                  "• Stops the app being uninstalled or switched off\n" +
                  "• Blocks installs and uninstalls (with Device Owner) and keeps new apps locked until you approve them\n• Choose apps with no time limit, or apps that are always blocked\n• Texts you only for a time request and for the nudity filter; everything else is listed in parent mode > Recent alerts\n• Every app is blocked unless you allow it. Phone and messages are always allowed with no time limit\n• Kid taps \"Ask for more time\": you text back OK 30 (or just OK for 15 min), OR enter your PIN on their phone and pick +15 / +30 / +60\n• Everything is enforced offline")),
            card(h("Quick setup for each phone"),
                p("1. Open KidGuard, type the child's name, a PIN and your number\n" +
                  "2. (Optional) tap \"Copy settings from another phone\" to reuse your limits and websites\n" +
                  "3. Follow the setup checklist in parent mode. Each button jumps to the right screen and the box ticks ✅ when done\n" +
                  "4. Tap \"Send test alert\" and check the text arrives")),
            card(h("Greyed-out switch or \"Restricted setting\"?"),
                p("Android 13+ blocks some switches for apps installed from a file. Go to Settings > Apps > KidGuard, " +
                  "tap the ⋮ menu (top right) and choose \"Allow restricted settings\". Then try again.")),
            card(h("Closing the Safe Mode / factory reset gap"),
                p("Without Device Owner, a determined kid can reboot into Safe Mode (which turns off all " +
                  "third-party apps) or factory reset the phone. Device Owner blocks both. It is a one-time " +
                  "step from a computer:\n" +
                  "1. Remove all accounts (incl. Google) from the phone temporarily\n" +
                  "2. Turn on Developer options > USB debugging, connect to a computer\n" +
                  "3. Run: adb shell dpm set-device-owner com.example.kidguard/.AdminReceiver\n" +
                  "4. Re-add your accounts\n" +
                  "5. Reopen parent mode: it should show the Device Owner lock is ON.\n" +
                  "Some brands (Xiaomi, Huawei, some Samsung) refuse this. Motorola usually works.")),
            card(h("Other good habits"),
                p("• Keep your parent PIN different from the phone's screen lock\n" +
                  "• Check Recent alerts in parent mode now and then\n" +
                  "• A text saying 'Phone restarted - protection is OFF' means something was switched off\n" +
                  "• No filter is perfect. Keep talking with your kid about what they see online")),
            backBtn()
        )
    }
}
