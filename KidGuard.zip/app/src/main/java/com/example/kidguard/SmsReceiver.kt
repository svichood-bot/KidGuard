package com.example.kidguard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

/**
 * Parent replies "OK 30" / "yes 30" / "more 30" / just "30" (also OK / YES alone = 15 min)
 * from their own number to give extra minutes today.
 * Note: this only works if the reply arrives as a normal SMS (not RCS / chat features).
 * The in-app PIN buttons on the kid's phone always work.
 */
class SmsReceiver : BroadcastReceiver() {
    private val word = Regex("^\\W*(ok|okay|yes|yep|y|more|add|approve|approved|extra)\\b\\D{0,12}(\\d{1,3})?",
        RegexOption.IGNORE_CASE)
    private val justNumber = Regex("^\\W*(\\d{1,3})\\s*(m|min|mins|minutes)?\\W*$", RegexOption.IGNORE_CASE)

    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        if (msgs.isEmpty()) return
        val from = msgs[0].originatingAddress ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }.trim()

        val mins: Int = word.find(body)?.let { (it.groupValues[2].toIntOrNull() ?: 15) }
            ?: justNumber.find(body)?.groupValues?.get(1)?.toIntOrNull()
            ?: return // not an approval text, ignore silently
        // A bare "ok"/"yes" (no number) only counts while a request is waiting, so normal chat can't hand out time.
        if (body.none { it.isDigit() } && !Store.requestPending(c)) return

        if (!Store.sameNumber(from, Store.phone(c))) {
            Store.log(c, "Ignored an approval-looking text from $from (not the saved parent number)")
            return
        }
        val m = mins.coerceIn(1, 240)
        Store.addBonus(c, m)
        Store.log(c, "Parent approved +$m min by text. ${Store.timeLeftMin(c)} min left.") // log only, no extra text
    }
}
