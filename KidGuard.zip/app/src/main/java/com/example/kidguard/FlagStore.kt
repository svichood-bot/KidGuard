package com.example.kidguard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.io.FileOutputStream

/**
 * Pictures the nudity filter flagged, so the parent can look and decide.
 * Kept ONLY in the app's private no-backup folder (never the gallery, never cloud backup)
 * and deleted automatically after 7 days.
 */
object FlagStore {
    class Item(val file: File, val time: Long, val pkg: String, val percent: Int, val id: Int = 0, val hash: Long? = null)

    private const val KEEP_MS = 7L * 24 * 60 * 60 * 1000
    private const val MAX_FILES = 30

    private fun dir(c: Context): File = File(c.noBackupFilesDir, "flags").apply { mkdirs() }

    private fun lum(p: Int) = (((p shr 16) and 0xFF) * 299 + ((p shr 8) and 0xFF) * 587 + (p and 0xFF) * 114) / 1000

    /** 64-bit "looks like" fingerprint of the screen (ignores the status/nav bars). Same picture on screen = (almost) same number. */
    fun hashOf(src: Bitmap): Long {
        return try {
            val top = (src.height * 0.06f).toInt()
            val body = Bitmap.createBitmap(src, 0, top, src.width, (src.height - 2 * top).coerceAtLeast(8))
            val mid = Bitmap.createScaledBitmap(body, 72, 64, true)
            val b = Bitmap.createScaledBitmap(mid, 9, 8, true)
            var h = 0L
            for (y in 0 until 8) for (x in 0 until 8)
                h = (h shl 1) or (if (lum(b.getPixel(x, y)) > lum(b.getPixel(x + 1, y))) 1L else 0L)
            h
        } catch (e: Exception) { 0L }
    }

    /** Saves the picture and returns its short number (used in "yes P7" texts), or 0 if saving failed. */
    fun save(c: Context, src: Bitmap, pkg: String, score: Float, hash: Long): Int {
        try {
            val longest = maxOf(src.width, src.height)
            val scale = if (longest > 900) 900f / longest else 1f
            val bmp = if (scale < 1f)
                Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true)
            else src
            val id = nextId(c)
            val name = "${System.currentTimeMillis()}__${pkg}__${(score * 100).toInt()}__${id}__${java.lang.Long.toHexString(hash)}.jpg"
            FileOutputStream(File(dir(c), name)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 70, it) }
            prune(c)
            return id
        } catch (e: Exception) { /* never let saving break the filter */ }
        return 0
    }

    private fun nextId(c: Context): Int {
        val sp = c.getSharedPreferences("kg", Context.MODE_PRIVATE)
        val id = (sp.getInt("flagSeq", 0) % 999) + 1
        sp.edit().putInt("flagSeq", id).apply()
        return id
    }

    private fun parse(f: File): Item? {
        val parts = f.name.removeSuffix(".jpg").split("__")
        if (parts.size != 3 && parts.size != 5) return null // 3 = older saves without a number
        val t = parts[0].toLongOrNull() ?: return null
        val id = if (parts.size == 5) parts[3].toIntOrNull() ?: 0 else 0
        val h = if (parts.size == 5) try { java.lang.Long.parseUnsignedLong(parts[4], 16) } catch (e: Exception) { null } else null
        return Item(f, t, parts[1], parts[2].toIntOrNull() ?: 0, id, h)
    }

    private fun prune(c: Context) {
        val now = System.currentTimeMillis()
        val items = (dir(c).listFiles() ?: emptyArray()).mapNotNull { parse(it) }.sortedByDescending { it.time }
        items.forEachIndexed { i, it -> if (i >= MAX_FILES || now - it.time > KEEP_MS) it.file.delete() }
    }

    /** Newest first. Old ones are removed as a side effect. */
    fun list(c: Context): List<Item> {
        prune(c)
        return (dir(c).listFiles() ?: emptyArray()).mapNotNull { parse(it) }.sortedByDescending { it.time }
    }

    fun find(c: Context, id: Int): Item? = if (id <= 0) null else list(c).firstOrNull { it.id == id }

    /** Parent looked and it's fine (e.g. an album cover): remember it so it is never flagged again, then drop the saved copy. */
    fun approve(c: Context, it: Item): Boolean {
        val h = it.hash ?: return false
        Store.approveImage(c, h)
        delete(it.file)
        return true
    }

    fun delete(f: File) { try { f.delete() } catch (e: Exception) {} }

    fun clear(c: Context) { (dir(c).listFiles() ?: emptyArray()).forEach { it.delete() } }

    /** Blocky, unreadable version for the list. The real picture only shows when the parent taps View. */
    fun pixelated(f: File): Bitmap? {
        return try {
            val o = BitmapFactory.Options().apply { inSampleSize = 8 }
            val b = BitmapFactory.decodeFile(f.path, o) ?: return null
            val h = (b.height.toFloat() / b.width).coerceAtLeast(0.2f)
            val small = Bitmap.createScaledBitmap(b, 12, (12 * h).toInt().coerceAtLeast(1), true)
            Bitmap.createScaledBitmap(small, 120, (120 * h).toInt().coerceAtLeast(1), false)
        } catch (e: Exception) { null }
    }

    fun full(f: File): Bitmap? = try { BitmapFactory.decodeFile(f.path) } catch (e: Exception) { null }
}
