package com.example.kidguard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.io.FileOutputStream

/**
 * Pictures the nudity filter flagged, so the parent can look and decide.
 * Kept ONLY in the app's private no-backup folder (never the gallery, never cloud backup)
 * and deleted automatically after 7 days.
 */
object FlagStore {
    class Item(val file: File, val time: Long, val pkg: String, val percent: Int)

    private const val KEEP_MS = 7L * 24 * 60 * 60 * 1000
    private const val MAX_FILES = 30

    private fun dir(c: Context): File = File(c.noBackupFilesDir, "flags").apply { mkdirs() }

    fun save(c: Context, src: Bitmap, pkg: String, score: Float) {
        try {
            val longest = maxOf(src.width, src.height)
            val scale = if (longest > 900) 900f / longest else 1f
            val bmp = if (scale < 1f)
                Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true)
            else src
            val name = "${System.currentTimeMillis()}__${pkg}__${(score * 100).toInt()}.jpg"
            FileOutputStream(File(dir(c), name)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 70, it) }
            prune(c)
        } catch (e: Exception) { /* never let saving break the filter */ }
    }

    private fun parse(f: File): Item? {
        val parts = f.name.removeSuffix(".jpg").split("__")
        if (parts.size != 3) return null
        val t = parts[0].toLongOrNull() ?: return null
        return Item(f, t, parts[1], parts[2].toIntOrNull() ?: 0)
    }

    private fun prune(c: Context) {
        val now = System.currentTimeMillis()
        val items = (dir(c).listFiles() ?: emptyArray()).mapNotNull { parse(it) }.sortedByDescending { it.time }
        items.forEachIndexed { i, it -> if (i >= MAX_FILES || now - it.time > KEEP_MS) it.file.delete() }
    }

    /** Newest first. Old ones are removed as a side effect. */
    fun list(c: Context): List<Item> {
        prune(c)
        return (dir(c).listFiles() ?: emptyArray()).mapNotNull { parse(it) }.sortedByDescending { it.time }
    }

    fun delete(f: File) { try { f.delete() } catch (e: Exception) {} }

    fun clear(c: Context) { (dir(c).listFiles() ?: emptyArray()).forEach { it.delete() } }

    /** Blocky, unreadable version for the list. The real picture only shows when the parent taps View. */
    fun pixelated(f: File): Bitmap? {
        return try {
            val o = BitmapFactory.Options().apply { inSampleSize = 8 }
            val b = BitmapFactory.decodeFile(f.path, o) ?: return null
            val h = (b.height.toFloat() / b.width).coerceAtLeast(0.2f)
            val small = Bitmap.createScaledBitmap(b, 12, (12 * h).toInt().coerceAtLeast(1), true)
            Bitmap.createScaledBitmap(small, 120, (120 * h).toInt().coerceAtLeast(1), false)
        } catch (e: Exception) { null }
    }

    fun full(f: File): Bitmap? = try { BitmapFactory.decodeFile(f.path) } catch (e: Exception) { null }
}
